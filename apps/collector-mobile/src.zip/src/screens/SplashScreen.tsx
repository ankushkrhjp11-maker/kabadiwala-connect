import { StyleSheet, Text, View } from 'react-native';
import { translations } from '../../../../packages/i18n/src';
import { colors, typography } from '../theme';

export function SplashScreen() {
  return <View style={styles.container}><View style={styles.mark}><Text style={styles.markText}>K</Text></View><Text style={typography.title}>{translations.en.appName}</Text><Text style={styles.tagline}>Saaf kaam. Behtar daam.</Text></View>;
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.brand },
  mark: { width: 86, height: 86, borderRadius: 28, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center', marginBottom: 18 },
  markText: { color: colors.brand, fontSize: 48, fontWeight: '900' },
  tagline: { color: '#DDF5EC', fontSize: 16, marginTop: 6 },
});
