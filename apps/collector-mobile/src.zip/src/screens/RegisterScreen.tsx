import { useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';

import { Button, Card, Field } from '../components/UI';
import { Screen } from '../components/Screen';
import type { AppLanguage, AppRoute } from '../navigation/types';
import { colors, spacing, typography } from '../theme';

type RegisterScreenProps = {
  language: AppLanguage;
  onNavigate: (route: AppRoute) => void;
};

export function RegisterScreen({
  language,
  onNavigate,
}: RegisterScreenProps) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState('');

  const isHindi = language === 'hi';
  const isMarathi = language === 'mr';

  const title = isHindi
    ? '\u0939\u092e\u0947\u0902 \u0905\u092a\u0928\u0947 \u092c\u093e\u0930\u0947 \u092e\u0947\u0902 \u092c\u0924\u093e\u090f\u0902'
    : isMarathi
      ? '\u0906\u092e\u094d\u0939\u093e\u0932\u093e \u0924\u0941\u092e\u091a\u094d\u092f\u093e\u092c\u0926\u094d\u0926\u0932 \u0938\u093e\u0902\u0917\u093e'
      : 'Help us know you better';

  const subtitle = isHindi
    ? '\u0905\u092a\u0928\u093e \u092a\u094d\u0930\u094b\u092b\u093e\u0907\u0932 \u092c\u0928\u093e\u0928\u0947 \u0915\u0947 \u0932\u093f\u090f \u0915\u0941\u091b \u091c\u093e\u0928\u0915\u093e\u0930\u0940 \u0926\u0947\u0902\u0964'
    : isMarathi
      ? '\u0924\u0941\u092e\u091a\u0947 \u092a\u094d\u0930\u094b\u092b\u093e\u0907\u0932 \u0924\u092f\u093e\u0930 \u0915\u0930\u0923\u094d\u092f\u093e\u0938\u093e\u0920\u0940 \u0915\u093e\u0939\u0940 \u092e\u093e\u0939\u093f\u0924\u0940 \u0926\u094d\u092f\u093e.'
      : 'Tell us a little about yourself to create your profile.';

  const nameLabel = isHindi
    ? '\u092a\u0942\u0930\u093e \u0928\u093e\u092e'
    : isMarathi
      ? '\u092a\u0942\u0930\u094d\u0923 \u0928\u093e\u0935'
      : 'Full name';

  const phoneLabel = isHindi
    ? '\u092e\u094b\u092c\u093e\u0907\u0932 \u0928\u0902\u092c\u0930'
    : isMarathi
      ? '\u092e\u094b\u092c\u093e\u0908\u0932 \u0928\u0902\u092c\u0930'
      : 'Mobile number';

  const namePlaceholder = isHindi
    ? '\u0905\u092a\u0928\u093e \u092a\u0942\u0930\u093e \u0928\u093e\u092e \u0932\u093f\u0916\u0947\u0902'
    : isMarathi
      ? '\u0924\u0941\u092e\u091a\u0947 \u092a\u0942\u0930\u094d\u0923 \u0928\u093e\u0935 \u0932\u093f\u0939\u093e'
      : 'Enter your full name';

  const continueLabel = isHindi
    ? '\u0906\u0917\u0947 \u092c\u0922\u093c\u0947\u0902'
    : isMarathi
      ? '\u092a\u0941\u0922\u0947 \u091c\u093e'
      : 'Continue';

  const secureTitle = isHindi
    ? '\u0906\u092a\u0915\u0940 \u091c\u093e\u0928\u0915\u093e\u0930\u0940 \u0938\u0941\u0930\u0915\u094d\u0937\u093f\u0924 \u0939\u0948'
    : isMarathi
      ? '\u0924\u0941\u092e\u091a\u0940 \u092e\u093e\u0939\u093f\u0924\u0940 \u0938\u0941\u0930\u0915\u094d\u0937\u093f\u0924 \u0906\u0939\u0947'
      : 'Your information is secure';

  const secureText = isHindi
    ? '\u0939\u092e \u0906\u092a\u0915\u0940 \u091c\u093e\u0928\u0915\u093e\u0930\u0940 \u0915\u093e \u0909\u092a\u092f\u094b\u0917 \u0915\u0947\u0935\u0932 \u0906\u092a\u0915\u0947 \u0905\u0915\u093e\u0909\u0902\u091f \u0914\u0930 \u0938\u0947\u0935\u093e \u0915\u0947 \u0932\u093f\u090f \u0915\u0930\u0947\u0902\u0917\u0947\u0964'
    : isMarathi
      ? '\u0906\u092e\u094d\u0939\u0940 \u0924\u0941\u092e\u091a\u0940 \u092e\u093e\u0939\u093f\u0924\u0940 \u092b\u0915\u094d\u0924 \u0924\u0941\u092e\u091a\u094d\u092f\u093e \u0905\u0915\u093e\u0909\u0902\u091f \u0906\u0923\u093f \u0938\u0947\u0935\u0947\u0938\u093e\u0920\u0940 \u0935\u093e\u092a\u0930\u0942.'
      : 'We use your information only for your account and service experience.';

  const footerText = isHindi
    ? '\u0932\u0917\u092d\u0917 1 \u092e\u093f\u0928\u091f \u092e\u0947\u0902 \u092a\u094d\u0930\u094b\u092b\u093e\u0907\u0932 \u0938\u0947\u091f\u0905\u092a \u092a\u0942\u0930\u093e \u0915\u0930\u0947\u0902'
    : isMarathi
      ? '\u0938\u0941\u092e\u093e\u0930\u0947 1 \u092e\u093f\u0928\u093f\u091f\u093e\u0924 \u092a\u094d\u0930\u094b\u092b\u093e\u0907\u0932 \u0938\u0947\u091f\u0905\u092a \u092a\u0942\u0930\u094d\u0923 \u0915\u0930\u093e'
      : 'Complete your profile setup in about 1 minute';

  function handleContinue() {
    const cleanName = name.trim();
    const cleanPhone = phone.trim();

    if (cleanName.length < 2) {
      setError(
        isHindi
          ? '\u0915\u0943\u092a\u092f\u093e \u0905\u092a\u0928\u093e \u0928\u093e\u092e \u0926\u0930\u094d\u091c \u0915\u0930\u0947\u0902\u0964'
          : isMarathi
            ? '\u0915\u0943\u092a\u092f\u093e \u0924\u0941\u092e\u091a\u0947 \u0928\u093e\u0935 \u092d\u0930\u093e.'
            : 'Please enter your name.',
      );
      return;
    }

    if (cleanPhone.length !== 10) {
      setError(
        isHindi
          ? '\u0915\u0943\u092a\u092f\u093e \u0938\u0939\u0940 10 \u0905\u0902\u0915\u094b\u0902 \u0915\u093e \u092e\u094b\u092c\u093e\u0907\u0932 \u0928\u0902\u092c\u0930 \u0926\u0930\u094d\u091c \u0915\u0930\u0947\u0902\u0964'
          : isMarathi
            ? '\u0915\u0943\u092a\u092f\u093e \u092f\u094b\u0917\u094d\u092f 10 \u0905\u0902\u0915\u0940 \u092e\u094b\u092c\u093e\u0908\u0932 \u0928\u0902\u092c\u0930 \u092d\u0930\u093e.'
            : 'Please enter a valid 10-digit mobile number.',
      );
      return;
    }

    setError('');
    onNavigate('roleSelection');
  }

  return (
    <Screen title={title} subtitle={subtitle}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.container}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.hero}>
          <View style={styles.iconCircle}>
            <Text style={styles.icon}>P</Text>
          </View>

          <Text style={styles.heroTitle}>
            {isHindi
              ? '\u0906\u092a\u0915\u0940 \u092a\u094d\u0930\u094b\u092b\u093e\u0907\u0932'
              : isMarathi
                ? '\u0924\u0941\u092e\u091a\u0947 \u092a\u094d\u0930\u094b\u092b\u093e\u0907\u0932'
                : 'Your profile'}
          </Text>

          <Text style={styles.heroText}>
            {isHindi
              ? '\u0906\u092a\u0915\u0940 \u091c\u093e\u0928\u0915\u093e\u0930\u0940 \u0906\u092a\u0915\u0947 \u0915\u093e\u092e \u0914\u0930 \u0932\u0947\u0928-\u0926\u0947\u0928 \u0915\u094b \u0935\u094d\u092f\u0935\u0938\u094d\u0925\u093f\u0924 \u0930\u0916\u0928\u0947 \u092e\u0947\u0902 \u092e\u0926\u0926 \u0915\u0930\u0947\u0917\u0940\u0964'
              : isMarathi
                ? '\u0924\u0941\u092e\u091a\u0940 \u092e\u093e\u0939\u093f\u0924\u0940 \u0924\u0941\u092e\u091a\u0947 \u0915\u093e\u092e \u0906\u0923\u093f \u0935\u094d\u092f\u0935\u0939\u093e\u0930 \u0935\u094d\u092f\u0935\u0938\u094d\u0925\u093f\u0924 \u0920\u0947\u0935\u0923\u094d\u092f\u093e\u0938 \u092e\u0926\u0924 \u0915\u0930\u0947\u0932.'
                : 'Your information helps us organize your collection work and transactions.'}
          </Text>
        </View>

        <Card accent>
          <Field
            label={nameLabel}
            placeholder={namePlaceholder}
            value={name}
            onChangeText={(value) => {
              setName(value);
              setError('');
            }}
          />

          <Field
            label={phoneLabel}
            placeholder="10-digit mobile number"
            value={phone}
            onChangeText={(value) => {
              setPhone(value.replace(/\D/g, '').slice(0, 10));
              setError('');
            }}
          />

          {error ? (
            <Text style={styles.error}>{error}</Text>
          ) : null}

          <Button
            label={continueLabel}
            onPress={handleContinue}
            icon=">"
          />
        </Card>

        <View style={styles.infoBox}>
          <View style={styles.lockCircle}>
            <Text style={styles.lockText}>S</Text>
          </View>

          <View style={styles.infoContent}>
            <Text style={styles.infoTitle}>{secureTitle}</Text>
            <Text style={styles.infoText}>{secureText}</Text>
          </View>
        </View>

        <Text style={styles.footer}>{footerText}</Text>
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingBottom: spacing.xl,
  },

  hero: {
    alignItems: 'center',
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
  },

  iconCircle: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: colors.brandSoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.sm,
  },

  icon: {
    color: colors.brand,
    fontSize: 32,
    fontWeight: '900',
  },

  heroTitle: {
    ...typography.heading,
    fontSize: 20,
    textAlign: 'center',
  },

  heroText: {
    ...typography.body,
    color: colors.muted,
    textAlign: 'center',
    marginTop: spacing.xs,
    lineHeight: 21,
  },

  error: {
    color: colors.danger,
    fontSize: 13,
    marginTop: -6,
    marginBottom: spacing.xs,
  },

  infoBox: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: colors.brandSoft,
    borderRadius: 16,
    padding: spacing.md,
    marginTop: spacing.sm,
  },

  lockCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.sm,
  },

  lockText: {
    color: colors.brand,
    fontSize: 15,
    fontWeight: '900',
  },

  infoContent: {
    flex: 1,
  },

  infoTitle: {
    color: colors.brandDark,
    fontSize: 14,
    fontWeight: '800',
  },

  infoText: {
    ...typography.body,
    color: colors.muted,
    fontSize: 13,
    lineHeight: 19,
    marginTop: 3,
  },

  footer: {
    ...typography.body,
    color: colors.muted,
    textAlign: 'center',
    fontSize: 12,
    marginTop: spacing.md,
  },
});