import { useState } from 'react';

import {
  Image,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';

import * as ImagePicker from 'expo-image-picker';

import { updateMyProfile } from '../services/authApi';

import { Screen } from '../components/Screen';
import { Button } from '../components/UI';

import type {
  AppLanguage,
  AppRoute,
  BusinessRole,
} from '../navigation/types';

import {
  colors,
  spacing,
  typography,
} from '../theme';

type Props = {
  language: AppLanguage;
  onNavigate: (route: AppRoute) => void;
  onRoleSelect: (role: BusinessRole) => void;
};

const roles: {
  value: BusinessRole;
  title: string;
  description: string;
  icon: string;
}[] = [
  {
    value: 'Recycler',
    title: 'Recycler',
    description:
      'Process e-waste and recover valuable materials.',
    icon: '♻️',
  },
  {
    value: 'Trader',
    title: 'Trader',
    description:
      'Buy and sell e-waste materials.',
    icon: '🤝',
  },
  {
    value: 'Manufacturer',
    title: 'Manufacturer',
    description:
      'Use recycled materials for manufacturing.',
    icon: '🏭',
  },
];

export function RoleSelectionScreen({
  language,
  onNavigate,
  onRoleSelect,
}: Props) {
  const [name, setName] = useState('');
  const [dob, setDob] = useState('');
  const [email, setEmail] = useState('');

  const [selectedRole, setSelectedRole] =
    useState<BusinessRole | null>(null);

  const [profileImage, setProfileImage] =
    useState<string | null>(null);

  const [roleModalVisible, setRoleModalVisible] =
    useState(false);

  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const text =
    language === 'hi'
      ? {
          title: 'हम आपको बेहतर जानना चाहते हैं',
          subtitle:
            'अपना विवरण पूरा करें और Kabadiwala Connect अकाउंट सेट करें।',

          name: 'नाम',
          namePlaceholder:
            'अपना पूरा नाम दर्ज करें',

          dob: 'जन्म तिथि',
          dobPlaceholder:
            'DD / MM / YYYY',

          role: 'अपनी भूमिका चुनें',
          rolePlaceholder:
            'अपनी भूमिका चुनें',

          email: 'ईमेल आईडी',
          emailPlaceholder:
            'अपना ईमेल पता दर्ज करें',

          picture: 'प्रोफाइल फोटो',
          optional: '(वैकल्पिक)',

          upload:
            'फोटो अपलोड करने या लेने के लिए टैप करें',

          continue: 'जारी रखें',

          required:
            'कृपया सभी जरूरी जानकारी भरें।',

          invalidEmail:
            'कृपया सही ईमेल आईडी दर्ज करें।',

          invalidDob:
            'कृपया सही जन्म तिथि दर्ज करें।',

          saveFailed:
            'प्रोफाइल सेव नहीं हो सकी। कृपया दोबारा कोशिश करें।',

          saving:
            'सेव हो रहा है...',
        }
      : language === 'mr'
        ? {
            title:
              'आम्हाला तुमच्याबद्दल अधिक जाणून घ्यायचे आहे',

            subtitle:
              'तुमचे तपशील पूर्ण करा आणि Kabadiwala Connect खाते सेट करा.',

            name: 'नाव',
            namePlaceholder:
              'तुमचे पूर्ण नाव टाका',

            dob: 'जन्मतारीख',
            dobPlaceholder:
              'DD / MM / YYYY',

            role: 'तुमची भूमिका निवडा',
            rolePlaceholder:
              'तुमची भूमिका निवडा',

            email: 'ईमेल आयडी',
            emailPlaceholder:
              'तुमचा ईमेल पत्ता टाका',

            picture: 'प्रोफाइल फोटो',
            optional: '(पर्यायी)',

            upload:
              'फोटो अपलोड किंवा घेण्यासाठी टॅप करा',

            continue: 'पुढे जा',

            required:
              'कृपया सर्व आवश्यक माहिती भरा.',

            invalidEmail:
              'कृपया योग्य ईमेल आयडी टाका.',

            invalidDob:
              'कृपया योग्य जन्मतारीख टाका.',

            saveFailed:
              'प्रोफाइल सेव्ह करता आले नाही. पुन्हा प्रयत्न करा.',

            saving:
              'सेव्ह होत आहे...',
          }
        : {
            title:
              'Help us know you better',

            subtitle:
              'Complete your details to set up your account with Kabadiwala Connect.',

            name: 'Name',
            namePlaceholder:
              'Enter your full name',

            dob: 'Date of Birth',
            dobPlaceholder:
              'DD / MM / YYYY',

            role: 'Select Your Role',
            rolePlaceholder:
              'Choose your role',

            email: 'Email ID',
            emailPlaceholder:
              'Enter your email address',

            picture: 'Profile Picture',
            optional: '(Optional)',

            upload:
              'Tap to upload or take a photo',

            continue: 'Continue',

            required:
              'Please fill all required details.',

            invalidEmail:
              'Please enter a valid email address.',

            invalidDob:
              'Please enter a valid date of birth.',

            saveFailed:
              'Unable to save profile. Please try again.',

            saving:
              'Saving...',
          };

  async function pickProfilePicture() {
    try {
      const permission =
        await ImagePicker.requestMediaLibraryPermissionsAsync();

      if (!permission.granted) {
        return;
      }

      const result =
        await ImagePicker.launchImageLibraryAsync({
          mediaTypes: ['images'],
          allowsEditing: true,
          aspect: [1, 1],
          quality: 0.8,
        });

      if (!result.canceled) {
        setProfileImage(
          result.assets[0].uri,
        );
      }
    } catch (error) {
      console.error(
        'Profile image selection failed:',
        error,
      );
    }
  }

  async function takeProfilePicture() {
    try {
      const permission =
        await ImagePicker.requestCameraPermissionsAsync();

      if (!permission.granted) {
        return;
      }

      const result =
        await ImagePicker.launchCameraAsync({
          allowsEditing: true,
          aspect: [1, 1],
          quality: 0.8,
        });

      if (!result.canceled) {
        setProfileImage(
          result.assets[0].uri,
        );
      }
    } catch (error) {
      console.error(
        'Profile camera failed:',
        error,
      );
    }
  }

  function convertDobToApiFormat(
    value: string,
  ): string | null {
    const parts = value
      .trim()
      .split('/')
      .map((part) => part.trim());

    if (parts.length !== 3) {
      return null;
    }

    const [day, month, year] = parts;

    if (
      day.length !== 2 ||
      month.length !== 2 ||
      year.length !== 4
    ) {
      return null;
    }

    const dayNumber = Number(day);
    const monthNumber = Number(month);
    const yearNumber = Number(year);

    if (
      !Number.isInteger(dayNumber) ||
      !Number.isInteger(monthNumber) ||
      !Number.isInteger(yearNumber)
    ) {
      return null;
    }

    if (
      monthNumber < 1 ||
      monthNumber > 12 ||
      dayNumber < 1 ||
      dayNumber > 31
    ) {
      return null;
    }

    const date = new Date(
      Date.UTC(
        yearNumber,
        monthNumber - 1,
        dayNumber,
      ),
    );

    if (
      date.getUTCFullYear() !== yearNumber ||
      date.getUTCMonth() !== monthNumber - 1 ||
      date.getUTCDate() !== dayNumber
    ) {
      return null;
    }

    if (date > new Date()) {
      return null;
    }

    return `${year}-${month}-${day}`;
  }

  async function handleContinue() {
    if (saving) {
      return;
    }

    const cleanName = name.trim();
    const cleanEmail =
      email.trim().toLowerCase();

    if (
      !cleanName ||
      !dob.trim() ||
      !selectedRole ||
      !cleanEmail
    ) {
      setError(text.required);
      return;
    }

    const emailIsValid =
      /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
        cleanEmail,
      );

    if (!emailIsValid) {
      setError(text.invalidEmail);
      return;
    }

    const formattedDob =
      convertDobToApiFormat(dob);

    if (!formattedDob) {
      setError(text.invalidDob);
      return;
    }

    const apiBusinessRole =
      selectedRole === 'Recycler'
        ? 'RECYCLER'
        : selectedRole === 'Trader'
          ? 'TRADER'
          : 'MANUFACTURER';

    try {
      setSaving(true);
      setError('');

      /*
       * IMPORTANT:
       * Save the complete registration data
       * into the backend database.
       */
      await updateMyProfile({
        name: cleanName,
        email: cleanEmail,
        dateOfBirth: formattedDob,
        businessRole: apiBusinessRole,

        ...(profileImage
          ? {
              profileImageReference:
                profileImage,
            }
          : {}),
      });

      /*
       * Keep role in local navigation state.
       */
      onRoleSelect(selectedRole);

      /*
       * Open the correct dashboard.
       */
      switch (selectedRole) {
        case 'Recycler':
          onNavigate(
            'recyclerDashboard',
          );
          break;

        case 'Trader':
          onNavigate(
            'traderDashboard',
          );
          break;

        case 'Manufacturer':
          onNavigate(
            'manufacturerDashboard',
          );
          break;
      }
    } catch (requestError) {
      console.error(
        'Profile registration failed:',
        requestError,
      );

      setError(
        requestError instanceof Error &&
          requestError.message
          ? requestError.message
          : text.saveFailed,
      );
    } finally {
      setSaving(false);
    }
  }

  return (
    <Screen
      title={text.title}
      subtitle={text.subtitle}
      showBack
      onBack={() => {
        if (!saving) {
          onNavigate('login');
        }
      }}
    >
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={
          styles.scrollContent
        }
      >
        <View style={styles.illustrationArea}>
          <View
            style={
              styles.illustrationCircleLarge
            }
          >
            <Text style={styles.earthIcon}>
              🌍
            </Text>
          </View>

          <View style={styles.leafOne}>
            <Text style={styles.leafText}>
              🌿
            </Text>
          </View>

          <View style={styles.leafTwo}>
            <Text style={styles.leafText}>
              🍃
            </Text>
          </View>
        </View>

        <View style={styles.formCard}>
          <FormRow icon="♙">
            <FieldLabel
              text={text.name}
              required
            />

            <InputBox
              value={name}
              placeholder={
                text.namePlaceholder
              }
              onChangeText={(value) => {
                setName(value);
                setError('');
              }}
            />
          </FormRow>

          <FormRow icon="▣">
            <FieldLabel
              text={text.dob}
              required
            />

            <InputBox
              value={dob}
              placeholder={
                text.dobPlaceholder
              }
              onChangeText={(value) => {
                const cleaned = value
                  .replace(/[^\d/]/g, '')
                  .slice(0, 10);

                setDob(cleaned);
                setError('');
              }}
              rightIcon="▣"
              keyboardType="default"
            />
          </FormRow>

          <FormRow icon="▣">
            <FieldLabel
              text={text.role}
              required
            />

            <Pressable
              onPress={() =>
                setRoleModalVisible(true)
              }
              style={styles.selectBox}
              disabled={saving}
            >
              <Text
                style={[
                  styles.selectText,
                  !selectedRole &&
                    styles.placeholderText,
                ]}
              >
                {selectedRole ??
                  text.rolePlaceholder}
              </Text>

              <Text style={styles.chevron}>
                ⌄
              </Text>
            </Pressable>

            {selectedRole ? (
              <View
                style={
                  styles.selectedRoleHint
                }
              >
                <Text
                  style={
                    styles.selectedRoleIcon
                  }
                >
                  {
                    roles.find(
                      (item) =>
                        item.value ===
                        selectedRole,
                    )?.icon
                  }
                </Text>

                <Text
                  style={
                    styles.selectedRoleDescription
                  }
                >
                  {
                    roles.find(
                      (item) =>
                        item.value ===
                        selectedRole,
                    )?.description
                  }
                </Text>
              </View>
            ) : null}
          </FormRow>

          <FormRow icon="✉">
            <FieldLabel
              text={text.email}
              required
            />

            <InputBox
              value={email}
              placeholder={
                text.emailPlaceholder
              }
              keyboardType="email-address"
              onChangeText={(value) => {
                setEmail(value);
                setError('');
              }}
            />
          </FormRow>

          <FormRow icon="▣">
            <View
              style={
                styles.pictureLabelRow
              }
            >
              <Text style={styles.fieldLabel}>
                {text.picture}
              </Text>

              <Text
                style={styles.optionalText}
              >
                {' '}
                {text.optional}
              </Text>
            </View>

            <Pressable
              onPress={pickProfilePicture}
              style={styles.uploadBox}
              disabled={saving}
            >
              {profileImage ? (
                <Image
                  source={{
                    uri: profileImage,
                  }}
                  style={
                    styles.profilePreview
                  }
                />
              ) : (
                <View
                  style={
                    styles.defaultAvatar
                  }
                >
                  <Text
                    style={
                      styles.avatarIcon
                    }
                  >
                    ♙
                  </Text>
                </View>
              )}

              <Text
                style={styles.uploadText}
              >
                {text.upload}
              </Text>

              <Pressable
                onPress={takeProfilePicture}
                style={styles.cameraButton}
                disabled={saving}
              >
                <Text
                  style={styles.cameraIcon}
                >
                  ◉
                </Text>
              </Pressable>
            </Pressable>
          </FormRow>

          {error ? (
            <View style={styles.errorBox}>
              <Text
                style={styles.errorText}
              >
                {error}
              </Text>
            </View>
          ) : null}

          <Button
            label={
              saving
                ? text.saving
                : text.continue
            }
            onPress={handleContinue}
            icon="→"
          />
        </View>
      </ScrollView>

      <Modal
        visible={roleModalVisible}
        transparent
        animationType="slide"
        onRequestClose={() =>
          setRoleModalVisible(false)
        }
      >
        <Pressable
          style={styles.modalOverlay}
          onPress={() =>
            setRoleModalVisible(false)
          }
        >
          <Pressable
            style={styles.roleModal}
            onPress={(event) =>
              event.stopPropagation()
            }
          >
            <View
              style={styles.modalHandle}
            />

            <Text
              style={styles.modalTitle}
            >
              {text.role}
            </Text>

            {roles.map((role) => (
              <Pressable
                key={role.value}
                onPress={() => {
                  setSelectedRole(
                    role.value,
                  );
                  setRoleModalVisible(
                    false,
                  );
                  setError('');
                }}
                style={({ pressed }) => [
                  styles.roleOption,
                  pressed &&
                    styles.roleOptionPressed,
                ]}
              >
                <View
                  style={
                    styles.roleIconCircle
                  }
                >
                  <Text
                    style={styles.roleIcon}
                  >
                    {role.icon}
                  </Text>
                </View>

                <View
                  style={styles.roleInfo}
                >
                  <Text
                    style={styles.roleTitle}
                  >
                    {role.title}
                  </Text>

                  <Text
                    style={
                      styles.roleDescription
                    }
                  >
                    {role.description}
                  </Text>
                </View>

                {selectedRole ===
                role.value ? (
                  <Text
                    style={
                      styles.checkMark
                    }
                  >
                    ✓
                  </Text>
                ) : null}
              </Pressable>
            ))}
          </Pressable>
        </Pressable>
      </Modal>
    </Screen>
  );
}

function FormRow({
  icon,
  children,
}: {
  icon: string;
  children: React.ReactNode;
}) {
  return (
    <View style={styles.formRow}>
      <View style={styles.leftIcon}>
        <Text
          style={styles.leftIconText}
        >
          {icon}
        </Text>
      </View>

      <View style={styles.formContent}>
        {children}
      </View>
    </View>
  );
}

function FieldLabel({
  text,
  required,
}: {
  text: string;
  required?: boolean;
}) {
  return (
    <Text style={styles.fieldLabel}>
      {text}

      {required ? (
        <Text style={styles.required}>
          {' '}
          *
        </Text>
      ) : null}
    </Text>
  );
}

function InputBox({
  value,
  placeholder,
  onChangeText,
  rightIcon,
  keyboardType,
}: {
  value: string;
  placeholder: string;
  onChangeText: (
    value: string,
  ) => void;
  rightIcon?: string;
  keyboardType?:
    | 'default'
    | 'email-address';
}) {
  return (
    <View style={styles.inputBox}>
      <TextInput
        value={value}
        placeholder={placeholder}
        placeholderTextColor="#93A39F"
        onChangeText={onChangeText}
        keyboardType={
          keyboardType ?? 'default'
        }
        style={styles.input}
      />

      {rightIcon ? (
        <Text style={styles.rightIcon}>
          {rightIcon}
        </Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    paddingBottom: 30,
  },

  illustrationArea: {
    height: 135,
    alignItems: 'flex-end',
    justifyContent: 'center',
    paddingRight: 20,
    position: 'relative',
  },

  illustrationCircleLarge: {
    width: 125,
    height: 125,
    borderRadius: 63,
    backgroundColor:
      colors.brandSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },

  earthIcon: {
    fontSize: 64,
  },

  leafOne: {
    position: 'absolute',
    right: 105,
    top: 15,
  },

  leafTwo: {
    position: 'absolute',
    right: 0,
    bottom: 5,
  },

  leafText: {
    fontSize: 34,
  },

  formCard: {
    backgroundColor: colors.surface,
    borderRadius: 26,
    padding: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border,
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 18,
    shadowOffset: {
      width: 0,
      height: 8,
    },
    elevation: 5,
  },

  formRow: {
    flexDirection: 'row',
    marginBottom: spacing.lg,
  },

  leftIcon: {
    width: 42,
    alignItems: 'flex-start',
    paddingTop: 3,
  },

  leftIconText: {
    fontSize: 27,
    color: colors.brand,
    fontWeight: '700',
  },

  formContent: {
    flex: 1,
  },

  fieldLabel: {
    fontSize: 18,
    lineHeight: 24,
    fontWeight: '800',
    color: colors.ink,
    marginBottom: spacing.sm,
  },

  required: {
    color: '#D33131',
  },

  optionalText: {
    fontSize: 14,
    color: colors.muted,
  },

  pictureLabelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },

  inputBox: {
    minHeight: 62,
    borderWidth: 1.5,
    borderColor: '#CFDBD7',
    borderRadius: 17,
    backgroundColor: '#FFFFFF',
    flexDirection: 'row',
    alignItems: 'center',
  },

  input: {
    flex: 1,
    paddingHorizontal: 18,
    paddingVertical: 15,
    fontSize: 16,
    color: colors.ink,
  },

  rightIcon: {
    fontSize: 23,
    color: colors.muted,
    marginRight: 16,
  },

  selectBox: {
    minHeight: 62,
    borderWidth: 1.5,
    borderColor: '#CFDBD7',
    borderRadius: 17,
    paddingHorizontal: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  selectText: {
    flex: 1,
    fontSize: 16,
    color: colors.ink,
  },

  placeholderText: {
    color: '#93A39F',
  },

  chevron: {
    fontSize: 27,
    color: colors.ink,
    marginLeft: 10,
  },

  selectedRoleHint: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
    paddingHorizontal: 4,
  },

  selectedRoleIcon: {
    fontSize: 21,
    marginRight: 7,
  },

  selectedRoleDescription: {
    flex: 1,
    color: colors.muted,
    fontSize: 12,
    lineHeight: 17,
  },

  uploadBox: {
    minHeight: 90,
    borderWidth: 1.5,
    borderStyle: 'dashed',
    borderColor: '#B9CCC6',
    borderRadius: 17,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
  },

  defaultAvatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#E5ECEA',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 13,
  },

  profilePreview: {
    width: 56,
    height: 56,
    borderRadius: 28,
    marginRight: 13,
  },

  avatarIcon: {
    fontSize: 32,
    color: '#7D8D89',
  },

  uploadText: {
    flex: 1,
    fontSize: 14,
    color: colors.muted,
    lineHeight: 20,
  },

  cameraButton: {
    width: 50,
    height: 50,
    borderLeftWidth: 1,
    borderLeftColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },

  cameraIcon: {
    fontSize: 28,
    color: colors.brand,
  },

  errorBox: {
    backgroundColor:
      colors.dangerSoft,
    borderRadius: 12,
    padding: 12,
    marginBottom: spacing.md,
  },

  errorText: {
    color: colors.danger,
    fontSize: 13,
    fontWeight: '600',
  },

  modalOverlay: {
    flex: 1,
    backgroundColor:
      'rgba(10, 30, 25, 0.38)',
    justifyContent: 'flex-end',
  },

  roleModal: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
    paddingBottom: 30,
  },

  modalHandle: {
    alignSelf: 'center',
    width: 45,
    height: 5,
    borderRadius: 3,
    backgroundColor: colors.border,
    marginBottom: spacing.md,
  },

  modalTitle: {
    ...typography.heading,
    marginBottom: spacing.sm,
  },

  roleOption: {
    minHeight: 82,
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor:
      colors.border,
    paddingVertical: spacing.sm,
  },

  roleOptionPressed: {
    opacity: 0.7,
  },

  roleIconCircle: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor:
      colors.brandSoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.md,
  },

  roleIcon: {
    fontSize: 25,
  },

  roleInfo: {
    flex: 1,
  },

  roleTitle: {
    fontSize: 17,
    fontWeight: '800',
    color: colors.ink,
  },

  roleDescription: {
    fontSize: 13,
    lineHeight: 18,
    color: colors.muted,
    marginTop: 3,
  },

  checkMark: {
    fontSize: 23,
    color: colors.brand,
    fontWeight: '800',
    marginLeft: 8,
  },
});