import { Text, StyleSheet } from 'react-native';
import { Screen } from '../components/Screen';
import { Card } from '../components/UI';
import { colors, spacing, typography } from '../theme';

const tips = [{ icon: '🔋', title: 'Battery and swelling', body: 'Do not puncture, open or throw a swollen battery. Keep it away from fire and tell your supervisor.' }, { icon: '🧤', title: 'Protect your hands', body: 'Wear gloves. Avoid touching broken glass, sharp metal or unknown powder with bare hands.' }, { icon: '⚡', title: 'Before you handle', body: 'Unplug devices first. Never dismantle an item connected to power.' }];

export function SafetyScreen() {
  return <Screen title="Safety first" subtitle="Small habits protect you and your family."><Card accent><Text style={styles.alert}>If something looks unsafe, stop and ask for help.</Text></Card>{tips.map((tip) => <Card key={tip.title}><Text style={styles.icon}>{tip.icon}</Text><Text style={styles.title}>{tip.title}</Text><Text style={styles.body}>{tip.body}</Text><Text style={styles.listen}>🔊  Tap to hear later</Text></Card>)}</Screen>;
}

const styles = StyleSheet.create({ alert: { ...typography.body, fontWeight: '800', color: colors.warning }, icon: { fontSize: 30 }, title: { ...typography.heading, fontSize: 18, marginTop: spacing.sm }, body: { ...typography.body, color: colors.muted, marginTop: spacing.xs }, listen: { color: colors.brand, fontWeight: '800', marginTop: spacing.md } });
