import { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { Button, Card, Field } from '../components/UI';
import { Screen } from '../components/Screen';

import type {
  AppLanguage,
  AppRoute,
} from '../navigation/types';

import { colors, spacing, typography } from '../theme';

import {
  loginWithPhone,
  saveAuthSession,
  getMyProfile,
} from '../services/authApi';

type Props = {
  language: AppLanguage;
  phone: string;
  onNavigate: (route: AppRoute) => void;
};

export function OtpScreen({
  language,
  phone,
  onNavigate,
}: Props) {
  const [otp, setOtp] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const content = {
    en: {
      title: 'Verify your mobile',
      subtitle:
        'Enter the 6-digit OTP sent to your mobile number.',
      otpLabel: 'One-time password',
      otpPlaceholder: 'Enter 6-digit OTP',
      verify: 'Verify & Continue',
      resend: 'Resend OTP',
      change: 'Change mobile number',
      demoTitle: 'Development OTP',
      demo: 'For development, use OTP 123456.',
      error: 'Please enter a valid 6-digit OTP.',
      loginError:
        'Unable to sign in. Please try again.',
      sentTo: 'OTP sent to',
      verifying: 'Checking account...',
    },

    hi: {
      title: 'मोबाइल सत्यापित करें',
      subtitle:
        'आपके मोबाइल नंबर पर भेजा गया 6 अंकों का OTP दर्ज करें।',
      otpLabel: 'OTP',
      otpPlaceholder: '6 अंकों का OTP दर्ज करें',
      verify: 'सत्यापित करें',
      resend: 'OTP दोबारा भेजें',
      change: 'मोबाइल नंबर बदलें',
      demoTitle: 'डेवलपमेंट OTP',
      demo:
        'डेवलपमेंट के लिए OTP 123456 इस्तेमाल करें।',
      error:
        'कृपया सही 6 अंकों का OTP दर्ज करें।',
      loginError:
        'साइन इन नहीं हो सका। कृपया दोबारा प्रयास करें।',
      sentTo: 'OTP भेजा गया',
      verifying: 'अकाउंट चेक हो रहा है...',
    },

    mr: {
      title: 'मोबाईल सत्यापित करा',
      subtitle:
        'तुमच्या मोबाईल नंबरवर पाठवलेला 6 अंकी OTP टाका.',
      otpLabel: 'OTP',
      otpPlaceholder: '6 अंकी OTP टाका',
      verify: 'Verify & Continue',
      resend: 'OTP पुन्हा पाठवा',
      change: 'मोबाईल नंबर बदला',
      demoTitle: 'डेव्हलपमेंट OTP',
      demo:
        'डेव्हलपमेंटसाठी OTP 123456 वापरा.',
      error:
        'कृपया योग्य 6 अंकी OTP टाका.',
      loginError:
        'साइन इन करता आले नाही. पुन्हा प्रयत्न करा.',
      sentTo: 'OTP पाठवला गेला',
      verifying: 'अकाउंट तपासत आहे...',
    },
  };

  const text = content[language];

  async function handleVerify() {
    // -----------------------------------------
    // 1. Validate OTP
    // -----------------------------------------
    if (otp !== '123456') {
      setError(text.error);
      return;
    }

    // -----------------------------------------
    // 2. Validate phone
    // -----------------------------------------
    const cleanPhone = phone.replace(/\D/g, '');

    if (cleanPhone.length !== 10) {
      setError(text.loginError);
      return;
    }

    // -----------------------------------------
    // 3. Prevent duplicate requests
    // -----------------------------------------
    if (loading) {
      return;
    }

    try {
      setLoading(true);
      setError('');

      // -----------------------------------------
      // 4. Login with backend
      // -----------------------------------------
      const response = await loginWithPhone(
        cleanPhone,
      );

      // -----------------------------------------
      // 5. Save JWT session
      //
      // Temporary local value is used only because
      // authStorage currently expects a role.
      // Actual role is fetched from database below.
      // -----------------------------------------
      await saveAuthSession(
        response,
        'Recycler',
      );

      // -----------------------------------------
      // 6. Get saved profile from DATABASE
      // -----------------------------------------
      const profile = await getMyProfile();

      // -----------------------------------------
      // 7. If profile exists and role is saved,
      //    directly open correct dashboard.
      // -----------------------------------------
      if (profile?.businessRole) {
        const savedRole =
          String(profile.businessRole).toUpperCase();

        console.log(
          'Saved business role:',
          savedRole,
        );

        // Recycler
        if (savedRole === 'RECYCLER') {
          onNavigate('recyclerDashboard');
          return;
        }

        // Trader
        if (savedRole === 'TRADER') {
          onNavigate('traderDashboard');
          return;
        }

        // Manufacturer
        if (savedRole === 'MANUFACTURER') {
          onNavigate(
            'manufacturerDashboard',
          );
          return;
        }
      }

      // -----------------------------------------
      // 8. No role found
      //    First-time registration
      // -----------------------------------------
      onNavigate('roleSelection');
    } catch (requestError) {
      console.error(
        'Authentication failed:',
        requestError,
      );

      if (requestError instanceof Error) {
        setError(requestError.message);
      } else {
        setError(text.loginError);
      }
    } finally {
      setLoading(false);
    }
  }

  function handleOtpChange(value: string) {
    const cleanValue = value
      .replace(/\D/g, '')
      .slice(0, 6);

    setOtp(cleanValue);
    setError('');
  }

  function handleResend() {
    setOtp('');
    setError('');
  }

  function handleChangePhone() {
    if (loading) {
      return;
    }

    setOtp('');
    setError('');

    onNavigate('login');
  }

  return (
    <Screen
      title={text.title}
      subtitle={text.subtitle}
    >
      <Card accent>
        {/* Phone Number */}
        <View style={styles.numberBox}>
          <Text style={styles.numberLabel}>
            {text.sentTo}
          </Text>

          <Text style={styles.phone}>
            {phone || 'Your mobile number'}
          </Text>
        </View>

        {/* OTP */}
        <Field
          label={text.otpLabel}
          placeholder={text.otpPlaceholder}
          value={otp}
          onChangeText={handleOtpChange}
          keyboardType="number-pad"
          maxLength={6}
        />

        {/* Error */}
        {error ? (
          <Text style={styles.error}>
            {error}
          </Text>
        ) : null}

        {/* Verify */}
        <Button
          label={
            loading
              ? text.verifying
              : text.verify
          }
          onPress={handleVerify}
        />

        {/* Actions */}
        <View style={styles.actions}>
          <Button
            label={text.resend}
            variant="secondary"
            onPress={handleResend}
          />

          <Button
            label={text.change}
            variant="quiet"
            onPress={handleChangePhone}
          />
        </View>
      </Card>

      {/* Development OTP */}
      <View style={styles.demoBox}>
        <View style={styles.demoIcon}>
          <Text style={styles.demoIconText}>
            i
          </Text>
        </View>

        <View style={styles.demoContent}>
          <Text style={styles.demoTitle}>
            {text.demoTitle}
          </Text>

          <Text style={styles.demoText}>
            {text.demo}
          </Text>
        </View>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  numberBox: {
    padding: spacing.md,
    marginBottom: spacing.md,
    borderRadius: 16,
    backgroundColor: colors.brandSoft,
  },

  numberLabel: {
    fontSize: 12,
    fontWeight: '700',
    color: colors.muted,
    marginBottom: 4,
  },

  phone: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.ink,
  },

  error: {
    marginTop: -4,
    marginBottom: spacing.md,
    color: colors.danger,
    fontSize: 13,
    fontWeight: '600',
  },

  actions: {
    marginTop: spacing.sm,
    gap: spacing.sm,
  },

  demoBox: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing.lg,
    padding: spacing.md,
    borderRadius: 16,
    backgroundColor: colors.brandSoft,
    borderWidth: 1,
    borderColor: colors.border,
  },

  demoIcon: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.brand,
    marginRight: spacing.sm,
  },

  demoIconText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },

  demoContent: {
    flex: 1,
  },

  demoTitle: {
    ...typography.label,
    marginBottom: 3,
  },

  demoText: {
    color: colors.muted,
    fontSize: 13,
    lineHeight: 19,
  },
});