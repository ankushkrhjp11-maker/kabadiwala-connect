import { useEffect, useState } from 'react';
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';

import { Screen } from '../components/Screen';
import {
  Button,
  Card,
  Chip,
  StateView,
} from '../components/UI';

import type { AppRoute } from '../navigation/types';
import type { LocalLot } from '../database/database';
import { getLots } from '../database/database';

import {
  colors,
  spacing,
  typography,
} from '../theme';

type MyLotsScreenProps = {
  onNavigate: (route: AppRoute) => void;
};

function getStatusText(status: LocalLot['status']) {
  switch (status) {
    case 'AVAILABLE':
      return 'Available';

    case 'SOLD':
      return 'Sold';

    case 'PENDING_SYNC':
      return 'Pending sync';

    default:
      return 'Pending';
  }
}

function getStatusColors(status: LocalLot['status']) {
  switch (status) {
    case 'AVAILABLE':
      return {
        background: '#E8F7EE',
        text: '#18864B',
      };

    case 'SOLD':
      return {
        background: '#EEF1F5',
        text: '#626B78',
      };

    case 'PENDING_SYNC':
      return {
        background: '#FFF4DD',
        text: '#A86B00',
      };

    default:
      return {
        background: '#EEF1F5',
        text: '#626B78',
      };
  }
}

function formatDate(value: string) {
  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return 'Date unavailable';
  }

  return date.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

function formatValue(value: number) {
  return `₹${Math.round(value).toLocaleString('en-IN')}`;
}

export function MyLotsScreen({
  onNavigate,
}: MyLotsScreenProps) {
  const [lots, setLots] = useState<LocalLot[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  async function loadLots() {
    try {
      setLoading(true);
      setError(false);

      const result = await getLots();

      setLots(result);
    } catch (err) {
      console.error('Failed to load lots:', err);
      setError(true);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadLots();
  }, []);

  if (loading) {
    return (
      <Screen
        title="My lots"
        subtitle="Your saved collection records."
      >
        <StateView
          icon="▱"
          title="Loading your lots"
          message="Reading your saved collection records..."
          loading
        />
      </Screen>
    );
  }

  if (error) {
    return (
      <Screen
        title="My lots"
        subtitle="Your saved collection records."
      >
        <StateView
          icon="!"
          title="Couldn't load your lots"
          message="Something went wrong while reading your saved lots."
          action={
            <Button
              label="Try again"
              onPress={loadLots}
            />
          }
        />
      </Screen>
    );
  }

  return (
    <Screen
      title="My lots"
      subtitle="Your saved collection records."
    >
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
      >
        {/* Header summary */}
        <View style={styles.summaryHeader}>
          <View>
            <Text style={styles.eyebrow}>
              COLLECTION
            </Text>

            <Text style={styles.heading}>
              Your e-waste lots
            </Text>

            <Text style={styles.subheading}>
              Keep track of everything you collect.
            </Text>
          </View>

          <View style={styles.countBadge}>
            <Text style={styles.count}>
              {lots.length}
            </Text>

            <Text style={styles.countLabel}>
              LOTS
            </Text>
          </View>
        </View>

        {/* Empty state */}
        {lots.length === 0 ? (
          <Card accent>
            <View style={styles.emptyContent}>
              <View style={styles.emptyIcon}>
                <Text style={styles.emptyEmoji}>
                  📦
                </Text>
              </View>

              <Text style={styles.emptyTitle}>
                No lots yet
              </Text>

              <Text style={styles.emptyMessage}>
                Start by creating your first collection
                lot. Your records will be stored safely
                on your phone.
              </Text>

              <Button
                icon="＋"
                label="Create your first lot"
                onPress={() =>
                  onNavigate('createLot')
                }
              />
            </View>
          </Card>
        ) : (
          <>
            {/* Statistics */}
            <View style={styles.statsRow}>
              <View style={styles.statCard}>
                <Text style={styles.statLabel}>
                  TOTAL LOTS
                </Text>

                <Text style={styles.statNumber}>
                  {lots.length}
                </Text>
              </View>

              <View style={styles.statCard}>
                <Text style={styles.statLabel}>
                  TOTAL WEIGHT
                </Text>

                <Text style={styles.statNumber}>
                  {lots
                    .reduce(
                      (sum, lot) =>
                        sum + lot.weightKg,
                      0,
                    )
                    .toFixed(1)}
                  kg
                </Text>
              </View>
            </View>

            {/* Section heading */}
            <View style={styles.sectionHeader}>
              <View>
                <Text style={styles.sectionTitle}>
                  Recent lots
                </Text>

                <Text style={styles.sectionSubtitle}>
                  Your latest collection records
                </Text>
              </View>

             <Chip>
  {`${lots.length} saved`}
</Chip>
            </View>

            {/* Lots */}
            {lots.map((lot) => {
              const status =
                getStatusColors(lot.status);

              return (
                <Card key={lot.id}>
                  {/* Lot heading */}
                  <View style={styles.lotHeader}>
                    <View style={styles.materialRow}>
                      <View style={styles.materialIcon}>
                        <Text style={styles.materialEmoji}>
                          {lot.materialIcon}
                        </Text>
                      </View>

                      <View style={styles.materialInfo}>
                        <Text style={styles.materialName}>
                          {lot.materialName}
                        </Text>

                        <Text style={styles.reference}>
                          {lot.reference}
                        </Text>
                      </View>
                    </View>

                    <View
                      style={[
                        styles.statusBadge,
                        {
                          backgroundColor:
                            status.background,
                        },
                      ]}
                    >
                      <View
                        style={[
                          styles.statusDot,
                          {
                            backgroundColor:
                              status.text,
                          },
                        ]}
                      />

                      <Text
                        style={[
                          styles.statusText,
                          {
                            color: status.text,
                          },
                        ]}
                      >
                        {getStatusText(
                          lot.status,
                        )}
                      </Text>
                    </View>
                  </View>

                  {/* Main information */}
                  <View style={styles.infoBox}>
                    <View style={styles.infoItem}>
                      <Text style={styles.infoLabel}>
                        WEIGHT
                      </Text>

                      <Text style={styles.infoValue}>
                        {lot.weightKg.toFixed(1)} kg
                      </Text>
                    </View>

                    <View style={styles.divider} />

                    <View style={styles.infoItem}>
                      <Text style={styles.infoLabel}>
                        ESTIMATED VALUE
                      </Text>

                      <Text style={styles.infoValue}>
                        {formatValue(
                          lot.estimatedLow,
                        )}{' '}
                        –{' '}
                        {formatValue(
                          lot.estimatedHigh,
                        )}
                      </Text>
                    </View>
                  </View>

                  {/* Date */}
                  <View style={styles.dateRow}>
                    <Text style={styles.dateIcon}>
                      🗓
                    </Text>

                    <View>
                      <Text style={styles.dateLabel}>
                        Collected on
                      </Text>

                      <Text style={styles.dateValue}>
                        {formatDate(
                          lot.collectionDate,
                        )}
                      </Text>
                    </View>
                  </View>

                  {/* Sync status */}
                  <View style={styles.bottomRow}>
                    <View style={styles.syncRow}>
                      <View
                        style={[
                          styles.syncDot,
                          {
                            backgroundColor:
                              lot.synced === 1
                                ? '#18864B'
                                : '#D99100',
                          },
                        ]}
                      />

                      <Text style={styles.syncText}>
                        {lot.synced === 1
                          ? 'Synced'
                          : 'Saved offline'}
                      </Text>
                    </View>

                    <Pressable
                      onPress={() => {
                        console.log(
                          'Lot selected:',
                          lot.id,
                        );
                      }}
                      style={({ pressed }) => [
                        styles.detailsButton,
                        pressed &&
                          styles.pressed,
                      ]}
                    >
                      <Text
                        style={
                          styles.detailsText
                        }
                      >
                        Details →
                      </Text>
                    </Pressable>
                  </View>
                </Card>
              );
            })}

            {/* Offline information */}
            <View style={styles.offlineBox}>
              <View style={styles.offlineIcon}>
                <Text style={styles.offlineIconText}>
                  ✓
                </Text>
              </View>

              <View style={styles.offlineContent}>
                <Text style={styles.offlineTitle}>
                  Your data is safe offline
                </Text>

                <Text style={styles.offlineText}>
                  Collection records are stored on this
                  phone and can be synchronized when
                  internet is available.
                </Text>
              </View>
            </View>

            {/* Create another */}
            <Button
              icon="＋"
              label="Create new lot"
              onPress={() =>
                onNavigate('createLot')
              }
            />
          </>
        )}
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: {
    paddingBottom: 40,
  },

  summaryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: spacing.lg,
  },

  eyebrow: {
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.4,
    color: colors.brand,
    marginBottom: 5,
  },

  heading: {
    ...typography.heading,
    color: colors.ink,
  },

  subheading: {
    ...typography.body,
    color: colors.muted,
    marginTop: 4,
  },

  countBadge: {
    width: 62,
    height: 62,
    borderRadius: 18,
    backgroundColor: colors.brandSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },

  count: {
    fontSize: 22,
    fontWeight: '800',
    color: colors.brand,
  },

  countLabel: {
    fontSize: 8,
    fontWeight: '800',
    letterSpacing: 1,
    color: colors.brand,
    marginTop: 1,
  },

  statsRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginBottom: spacing.lg,
  },

  statCard: {
    flex: 1,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 17,
    padding: spacing.md,
  },

  statLabel: {
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 0.8,
    color: colors.muted,
  },

  statNumber: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.ink,
    marginTop: 6,
  },

  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: spacing.sm,
  },

  sectionTitle: {
    fontSize: 17,
    fontWeight: '800',
    color: colors.ink,
  },

  sectionSubtitle: {
    fontSize: 11,
    color: colors.muted,
    marginTop: 3,
  },

  emptyContent: {
    alignItems: 'center',
    paddingVertical: spacing.md,
  },

  emptyIcon: {
    width: 76,
    height: 76,
    borderRadius: 25,
    backgroundColor: colors.brandSoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.md,
  },

  emptyEmoji: {
    fontSize: 34,
  },

  emptyTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.ink,
  },

  emptyMessage: {
    ...typography.body,
    color: colors.muted,
    textAlign: 'center',
    marginTop: spacing.xs,
    marginBottom: spacing.lg,
    lineHeight: 20,
  },

  lotHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: spacing.sm,
  },

  materialRow: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },

  materialIcon: {
    width: 48,
    height: 48,
    borderRadius: 15,
    backgroundColor: colors.brandSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },

  materialEmoji: {
    fontSize: 24,
  },

  materialInfo: {
    flex: 1,
    marginLeft: spacing.sm,
  },

  materialName: {
    fontSize: 15,
    fontWeight: '800',
    color: colors.ink,
  },

  reference: {
    fontSize: 10,
    fontWeight: '600',
    color: colors.muted,
    marginTop: 3,
  },

  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 999,
    paddingHorizontal: 8,
    paddingVertical: 6,
  },

  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginRight: 5,
  },

  statusText: {
    fontSize: 9,
    fontWeight: '800',
  },

  infoBox: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing.md,
    paddingVertical: spacing.sm,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: colors.border,
  },

  infoItem: {
    flex: 1,
  },

  divider: {
    width: 1,
    height: 32,
    backgroundColor: colors.border,
    marginHorizontal: spacing.sm,
  },

  infoLabel: {
    fontSize: 8,
    fontWeight: '800',
    letterSpacing: 0.7,
    color: colors.muted,
  },

  infoValue: {
    fontSize: 13,
    fontWeight: '800',
    color: colors.ink,
    marginTop: 4,
  },

  dateRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing.sm,
  },

  dateIcon: {
    fontSize: 16,
    marginRight: spacing.sm,
  },

  dateLabel: {
    fontSize: 9,
    color: colors.muted,
    fontWeight: '600',
  },

  dateValue: {
    fontSize: 12,
    color: colors.ink,
    fontWeight: '700',
    marginTop: 2,
  },

  bottomRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: spacing.md,
    paddingTop: spacing.sm,
    borderTopWidth: 1,
    borderColor: colors.border,
  },

  syncRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  syncDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    marginRight: 6,
  },

  syncText: {
    fontSize: 10,
    color: colors.muted,
    fontWeight: '600',
  },

  detailsButton: {
    paddingVertical: 6,
    paddingHorizontal: 4,
  },

  detailsText: {
    fontSize: 11,
    color: colors.brand,
    fontWeight: '800',
  },

  pressed: {
    opacity: 0.55,
  },

  offlineBox: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: colors.brandSoft,
    borderRadius: 17,
    padding: spacing.md,
    marginVertical: spacing.md,
  },

  offlineIcon: {
    width: 30,
    height: 30,
    borderRadius: 10,
    backgroundColor: colors.brand,
    alignItems: 'center',
    justifyContent: 'center',
  },

  offlineIconText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '900',
  },

  offlineContent: {
    flex: 1,
    marginLeft: spacing.sm,
  },

  offlineTitle: {
    fontSize: 13,
    fontWeight: '800',
    color: colors.ink,
  },

  offlineText: {
    fontSize: 10,
    lineHeight: 16,
    color: colors.muted,
    marginTop: 3,
  },
});