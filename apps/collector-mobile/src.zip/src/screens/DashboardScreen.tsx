import { Text, StyleSheet, View } from 'react-native';

import {
  Card,
  Button,
  Chip,
} from '../components/UI';

import { Screen } from '../components/Screen';

import type { AppRoute } from '../navigation/types';

import {
  colors,
  spacing,
  typography,
} from '../theme';

type BusinessRole =
  | 'Recycler'
  | 'Trader'
  | 'Manufacturer';

type DashboardScreenProps = {
  onNavigate: (route: AppRoute) => void;
  businessRole?: BusinessRole;
};

export function DashboardScreen({
  onNavigate,
  businessRole,
}: DashboardScreenProps) {
  /*
   * Create Lot is ONLY available for Recycler.
   *
   * Trader       -> hidden
   * Manufacturer -> hidden
   * Recycler     -> visible
   */
  const canCreateLot =
    businessRole === 'Recycler';

  return (
    <Screen
      title="Namaste, Collector"
      subtitle="Ready to turn e-waste into value?"
    >
      {/* =====================================================
          EARNINGS SUMMARY
         ===================================================== */}

      <Card accent>
        <View style={styles.syncRow}>
          <Chip>
            Offline ready
          </Chip>

          <Text style={styles.sync}>
            Last sync: just now
          </Text>
        </View>

        <Text style={styles.balanceLabel}>
          This month’s earnings
        </Text>

        <Text style={styles.balance}>
          ₹ 0
        </Text>

        <Text style={styles.small}>
          Start your first lot to see earnings here.
        </Text>
      </Card>

      {/* =====================================================
          CREATE LOT
          ONLY RECYCLER
         ===================================================== */}

      {canCreateLot && (
        <View style={styles.createLotContainer}>
          <Button
            icon="＋"
            label="Create a new lot"
            onPress={() => {
              onNavigate('createLot');
            }}
          />
        </View>
      )}

      {/* =====================================================
          QUICK ACTIONS
         ===================================================== */}

      <Text style={styles.section}>
        Quick actions
      </Text>

      <View style={styles.grid}>

        {/* MY LOTS */}

        <Card
          onPress={() => {
            onNavigate('myLots');
          }}
        >
          <Text style={styles.icon}>
            ▣
          </Text>

          <Text style={styles.cardTitle}>
            My lots
          </Text>

          <Text style={styles.cardHint}>
            Track your items
          </Text>
        </Card>

        {/* SAFETY */}

        <Card
          onPress={() => {
            onNavigate('safety');
          }}
        >
          <Text style={styles.icon}>
            ♧
          </Text>

          <Text style={styles.cardTitle}>
            Safety first
          </Text>

          <Text style={styles.cardHint}>
            Handling guidance
          </Text>
        </Card>

        {/* EARNINGS */}

        <Card
          onPress={() => {
            onNavigate('earnings');
          }}
        >
          <Text style={styles.icon}>
            ₹
          </Text>

          <Text style={styles.cardTitle}>
            Earnings
          </Text>

          <Text style={styles.cardHint}>
            View your ledger
          </Text>
        </Card>

        {/* PROFILE */}

        <Card
          onPress={() => {
            onNavigate('profile');
          }}
        >
          <Text style={styles.icon}>
            ●
          </Text>

          <Text style={styles.cardTitle}>
            My profile
          </Text>

          <Text style={styles.cardHint}>
            Your account
          </Text>
        </Card>

      </View>
    </Screen>
  );
}

/* =========================================================
   STYLES
   ========================================================= */

const styles = StyleSheet.create({
  syncRow: {
    flexDirection: 'row',

    alignItems: 'center',

    justifyContent: 'space-between',
  },

  sync: {
    color: colors.muted,

    fontSize: 12,
  },

  balanceLabel: {
    ...typography.label,

    marginTop: spacing.lg,
  },

  balance: {
    fontSize: 34,

    fontWeight: '900',

    color: colors.brandDark,

    marginTop: 2,
  },

  small: {
    ...typography.body,

    color: colors.muted,

    marginTop: 2,
  },

  createLotContainer: {
    marginTop: spacing.md,
  },

  section: {
    ...typography.heading,

    fontSize: 18,

    marginVertical: spacing.md,
  },

  grid: {
    flexDirection: 'row',

    flexWrap: 'wrap',

    justifyContent: 'space-between',
  },

  icon: {
    color: colors.brand,

    fontSize: 27,

    marginBottom: spacing.sm,
  },

  cardTitle: {
    ...typography.body,

    fontWeight: '800',
  },

  cardHint: {
    color: colors.muted,

    fontSize: 13,

    marginTop: 3,
  },
});