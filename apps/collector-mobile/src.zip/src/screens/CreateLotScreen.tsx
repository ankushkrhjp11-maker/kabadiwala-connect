import { useMemo, useState } from 'react';
import {
  Alert,
  Image,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';

import { Button, Card, Chip, Field } from '../components/UI';
import { Screen } from '../components/Screen';
import type { AppRoute } from '../navigation/types';
import { colors, spacing, typography } from '../theme';
import { createLot as saveLocalLot } from '../database/database';
import { API_BASE_URL } from '../config/api';

import {
  validateEwastePhoto,
  type PhotoValidationResult,
} from '../services/photoValidation';

const MATERIALS = [
  { id: 'pcb', label: 'PCB', icon: '🟩' },
  { id: 'cables', label: 'Cables', icon: '🔌' },
  { id: 'battery', label: 'Batteries', icon: '🔋' },
  { id: 'crt', label: 'CRT', icon: '📺' },
  { id: 'lcd', label: 'LCD / LED', icon: '🖥️' },
  { id: 'motor', label: 'Motors', icon: '⚙️' },
  { id: 'plastic', label: 'Mixed Plastics', icon: '♻️' },
  { id: 'other', label: 'Other E-waste', icon: '📦' },
];

type Props = {
  onNavigate: (route: AppRoute) => void;
};

type ImageAsset = ImagePicker.ImagePickerAsset;

export function CreateLotScreen({ onNavigate }: Props) {
  const [step, setStep] = useState(1);

  const [category, setCategory] = useState('');
  const [weight, setWeight] = useState('');
  const [notes, setNotes] = useState('');

  const [photoUri, setPhotoUri] = useState<string | null>(null);
  const [photoAsset, setPhotoAsset] =
    useState<ImageAsset | null>(null);

  const [photoValidation, setPhotoValidation] =
    useState<PhotoValidationResult | null>(null);

  const [validatingPhoto, setValidatingPhoto] =
    useState(false);

  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);

  const selectedMaterial = useMemo(
    () => MATERIALS.find((item) => item.id === category),
    [category],
  );

  const numericWeight = Number(weight);

  const estimatedRange = useMemo(() => {
    if (!numericWeight || numericWeight <= 0 || !category) {
      return null;
    }

    const rates: Record<string, [number, number]> = {
      pcb: [120, 220],
      cables: [80, 150],
      battery: [45, 90],
      crt: [20, 45],
      lcd: [35, 70],
      motor: [70, 130],
      plastic: [15, 35],
      other: [20, 60],
    };

    const [lowRate, highRate] =
      rates[category] ?? [20, 60];

    return {
      low: Math.round(numericWeight * lowRate),
      high: Math.round(numericWeight * highRate),
    };
  }, [category, numericWeight]);

  /**
   * AI PHOTO VALIDATION
   *
   * Mobile
   *   ↓
   * NestJS /api/ai/validate-image
   *   ↓
   * Python FastAPI /validate
   *   ↓
   * CLIP
   *   ↓
   * ACCEPT / REJECT / VERIFY
   */
  async function verifyPhoto(
    asset: ImageAsset,
    selectedCategory: string,
  ) {
    if (!selectedCategory) {
      setPhotoValidation(null);

      Alert.alert(
        'Select material first',
        'Please select the material category before verifying the photo.',
      );

      return;
    }

    try {
      setValidatingPhoto(true);
      setPhotoValidation(null);

      console.log(
        '[AI] Starting photo validation',
      );

      console.log(
        '[AI] API:',
        `${API_BASE_URL}/ai/validate-image`,
      );

      const result =
        await validateEwastePhoto(
          asset,
          selectedCategory,
        );

      console.log(
        '[AI] Validation result:',
        result,
      );

      setPhotoValidation(result);

      if (result.decision === 'ACCEPT') {
        Alert.alert(
          'Photo verified ✓',
          `${result.reason}\n\nConfidence: ${Math.round(
            result.confidence * 100,
          )}%`,
        );
      } else if (
        result.decision === 'REJECT'
      ) {
        Alert.alert(
          'Photo rejected',
          result.reason ||
            'The image does not match the selected e-waste material.',
        );
      } else {
        Alert.alert(
          'Verification required',
          result.reason ||
            'The image needs additional verification.',
        );
      }
    } catch (error) {
      console.error(
        '[AI] Photo validation error:',
        error,
      );

      setPhotoValidation(null);

      Alert.alert(
        'AI verification failed',
        'The photo could not be verified. Please check that the API and AI service are running and the phone is connected to the same network.',
      );
    } finally {
      setValidatingPhoto(false);
    }
  }

  /**
   * CAMERA
   */
  async function takePhoto() {
    try {
      const permission =
        await ImagePicker.requestCameraPermissionsAsync();

      if (!permission.granted) {
        Alert.alert(
          'Camera permission needed',
          'Please allow camera access to photograph the collected e-waste item.',
        );

        return;
      }

      const result =
        await ImagePicker.launchCameraAsync({
          mediaTypes: ['images'],
          quality: 0.8,
          allowsEditing: true,
          aspect: [4, 3],
        });

      if (
        result.canceled ||
        !result.assets[0]?.uri
      ) {
        return;
      }

      const asset = result.assets[0];

      setPhotoUri(asset.uri);
      setPhotoAsset(asset);
      setPhotoValidation(null);

      if (category) {
        await verifyPhoto(
          asset,
          category,
        );
      }
    } catch (error) {
      console.error(
        'Camera error:',
        error,
      );

      Alert.alert(
        'Camera error',
        'Unable to open the camera. Please try again.',
      );
    }
  }

  /**
   * GALLERY
   */
  async function chooseFromGallery() {
    try {
      const permission =
        await ImagePicker.requestMediaLibraryPermissionsAsync();

      if (!permission.granted) {
        Alert.alert(
          'Gallery permission needed',
          'Please allow photo access to select an e-waste image.',
        );

        return;
      }

      const result =
        await ImagePicker.launchImageLibraryAsync({
          mediaTypes: ['images'],
          quality: 0.8,
          allowsEditing: true,
          aspect: [4, 3],
        });

      if (
        result.canceled ||
        !result.assets[0]?.uri
      ) {
        return;
      }

      const asset = result.assets[0];

      setPhotoUri(asset.uri);
      setPhotoAsset(asset);
      setPhotoValidation(null);

      if (category) {
        await verifyPhoto(
          asset,
          category,
        );
      }
    } catch (error) {
      console.error(
        'Gallery error:',
        error,
      );

      Alert.alert(
        'Gallery error',
        'Unable to select the image. Please try again.',
      );
    }
  }

  /**
   * PHOTO MENU
   */
  function handlePhotoPress() {
    Alert.alert(
      'Add e-waste photo',
      'A clear photo of the actual collected item is required.',
      [
        {
          text: 'Take photo',
          onPress: takePhoto,
        },
        {
          text: 'Choose from gallery',
          onPress: chooseFromGallery,
        },
        {
          text: 'Cancel',
          style: 'cancel',
        },
      ],
    );
  }

  /**
   * MATERIAL SELECT
   */
  async function handleCategorySelect(
    materialId: string,
  ) {
    setCategory(materialId);

    setPhotoValidation(null);

    if (photoAsset) {
      await verifyPhoto(
        photoAsset,
        materialId,
      );
    }
  }

  /**
   * STEP 1 → STEP 2
   */
  async function continueToStepTwo() {
    if (!photoUri || !photoAsset) {
      Alert.alert(
        'Photo required',
        'Please take or select a clear photo of the collected e-waste item.',
      );

      return;
    }

    if (!category) {
      Alert.alert(
        'Select material',
        'Please select the material category.',
      );

      return;
    }

    if (
      !numericWeight ||
      numericWeight <= 0
    ) {
      Alert.alert(
        'Enter weight',
        'Please enter a valid approximate weight in kilograms.',
      );

      return;
    }

    if (validatingPhoto) {
      Alert.alert(
        'Please wait',
        'AI is still checking the photo. Please wait until verification is complete.',
      );

      return;
    }

    if (!photoValidation) {
      Alert.alert(
        'Photo verification required',
        'The photo must pass AI verification before you can continue.',
      );

      await verifyPhoto(
        photoAsset,
        category,
      );

      return;
    }

    if (
      photoValidation.decision !==
      'ACCEPT'
    ) {
      Alert.alert(
        'Photo rejected',
        photoValidation.reason ||
          'The photo did not pass e-waste verification.',
      );

      return;
    }

    if (
      photoValidation.predictedCategory !==
      category
    ) {
      Alert.alert(
        'Wrong material',
        `You selected "${selectedMaterial?.label}", but AI detected "${photoValidation.predictedCategory}". Please select the correct material or upload the correct photo.`,
      );

      return;
    }

    if (
      photoValidation.selectedCategory !==
      category
    ) {
      Alert.alert(
        'Material mismatch',
        'The selected material does not match the verified photo.',
      );

      return;
    }

    setStep(2);
  }

  /**
   * SAVE LOT
   */
  async function saveLot() {
    if (!photoUri || !photoAsset) {
      Alert.alert(
        'Photo required',
        'A photo is required before saving the lot.',
      );

      setStep(1);
      return;
    }

    if (validatingPhoto) {
      Alert.alert(
        'Please wait',
        'AI is still verifying the photo.',
      );

      return;
    }

    if (
      !photoValidation ||
      photoValidation.decision !==
        'ACCEPT'
    ) {
      Alert.alert(
        'Photo verification required',
        'This lot cannot be saved because the photo has not passed AI verification.',
      );

      setStep(1);
      return;
    }

    if (
      photoValidation.predictedCategory !==
        category ||
      photoValidation.selectedCategory !==
        category
    ) {
      Alert.alert(
        'Material mismatch',
        'The verified photo does not match the selected material.',
      );

      setStep(1);
      return;
    }

    if (!selectedMaterial) {
      Alert.alert(
        'Material required',
        'Please select the material category.',
      );

      setStep(1);
      return;
    }

    if (
      !numericWeight ||
      numericWeight <= 0
    ) {
      Alert.alert(
        'Invalid weight',
        'Please enter a valid approximate weight.',
      );

      setStep(1);
      return;
    }

    if (!estimatedRange) {
      Alert.alert(
        'Value unavailable',
        'Unable to calculate the preliminary value.',
      );

      return;
    }

    try {
      setSaving(true);

      const lotId =
        `${Date.now()}-${Math.random()
          .toString(36)
          .slice(2, 8)}`;

      const reference =
        `KC-2026-${Date.now()
          .toString()
          .slice(-5)}`;

      await saveLocalLot({
        id: lotId,
        reference,
        materialId:
          selectedMaterial.id,
        materialName:
          selectedMaterial.label,
        materialIcon:
          selectedMaterial.icon,
        weightKg:
          numericWeight,
        estimatedLow:
          estimatedRange.low,
        estimatedHigh:
          estimatedRange.high,
        notes,
        photoUri,
        status: 'PENDING_SYNC',
        collectionDate:
          new Date().toISOString(),
        location:
          'Location unavailable',
        synced: 0,
      });

      setSaved(true);
    } catch (error) {
      console.error(
        'Failed to save lot:',
        error,
      );

      Alert.alert(
        'Could not save lot',
        'The lot could not be saved on this device. Please try again.',
      );
    } finally {
      setSaving(false);
    }
  }

  /**
   * RESET
   */
  function resetForm() {
    setStep(1);
    setCategory('');
    setWeight('');
    setNotes('');

    setPhotoUri(null);
    setPhotoAsset(null);
    setPhotoValidation(null);

    setValidatingPhoto(false);

    setSaved(false);
    setSaving(false);
  }

  /**
   * SUCCESS SCREEN
   */
  if (saved) {
    return (
      <Screen
        title="Lot saved"
        subtitle="Your collection record is saved on this phone."
      >
        <Card accent>
          <View style={styles.successIcon}>
            <Text
              style={
                styles.successIconText
              }
            >
              ✓
            </Text>
          </View>

          <Chip>
            OFFLINE SAVED
          </Chip>

          <Text style={styles.savedTitle}>
            Lot is ready to sync
          </Text>

          <Text style={styles.savedText}>
            Your collection details and
            verified photo are stored on
            this phone. They can be
            synchronized with the
            recycling network when
            internet is available.
          </Text>

          <View style={styles.summaryBox}>
            <Text
              style={styles.summaryLabel}
            >
              MATERIAL
            </Text>

            <Text
              style={styles.summaryValue}
            >
              {selectedMaterial?.icon}{' '}
              {selectedMaterial?.label}
            </Text>

            <Text
              style={styles.summaryLabel}
            >
              APPROX. WEIGHT
            </Text>

            <Text
              style={styles.summaryValue}
            >
              {weight} kg
            </Text>

            <Text
              style={styles.summaryLabel}
            >
              PHOTO
            </Text>

            <Text
              style={styles.summaryValue}
            >
              AI Verified ✓
            </Text>

            <Text
              style={styles.summaryLabel}
            >
              STATUS
            </Text>

            <Text
              style={styles.summaryValue}
            >
              Pending sync
            </Text>
          </View>

          <Button
            label="View my lots"
            onPress={() =>
              onNavigate('myLots')
            }
          />

          <Button
            label="Create another lot"
            variant="secondary"
            onPress={resetForm}
          />
        </Card>
      </Screen>
    );
  }

  return (
    <Screen
      title="Create a lot"
      subtitle="Add what you collected today."
    >
      <Card>

        {/* PROGRESS */}
        <View style={styles.progressRow}>
          <Text style={styles.step}>
            STEP {step} OF 2
          </Text>

          <Text style={styles.stepStatus}>
            {step === 1
              ? 'ITEM DETAILS'
              : 'REVIEW & VALUE'}
          </Text>
        </View>

        {/* STEP 1 */}
        {step === 1 ? (
          <>
            {/* PHOTO */}
            <View
              style={
                styles.sectionHeadingRow
              }
            >
              <View style={styles.stepNumber}>
                <Text
                  style={
                    styles.stepNumberText
                  }
                >
                  1
                </Text>
              </View>

              <View>
                <Text
                  style={
                    styles.sectionTitle
                  }
                >
                  Add a photo *
                </Text>

                <Text
                  style={
                    styles.requiredText
                  }
                >
                  Required for AI material
                  verification
                </Text>
              </View>
            </View>

            <Pressable
              style={[
                styles.photoBox,
                photoUri &&
                  styles.photoBoxFilled,
              ]}
              onPress={
                handlePhotoPress
              }
            >
              {photoUri ? (
                <>
                  <Image
                    source={{
                      uri: photoUri,
                    }}
                    style={
                      styles.photoPreview
                    }
                  />

                  <View
                    style={[
                      styles.verifiedPhotoBadge,

                      photoValidation?.decision ===
                        'REJECT' &&
                        styles.rejectedPhotoBadge,

                      validatingPhoto &&
                        styles.checkingPhotoBadge,
                    ]}
                  >
                    <Text
                      style={
                        styles.verifiedPhotoText
                      }
                    >
                      {validatingPhoto
                        ? 'AI CHECKING...'
                        : photoValidation?.decision ===
                            'ACCEPT'
                          ? '✓ PHOTO VERIFIED'
                          : photoValidation?.decision ===
                              'REJECT'
                            ? '✕ PHOTO REJECTED'
                            : 'PHOTO ADDED'}
                    </Text>
                  </View>

                  <View
                    style={
                      styles.photoOverlay
                    }
                  >
                    <Text
                      style={
                        styles.photoOverlayText
                      }
                    >
                      Change photo
                    </Text>
                  </View>
                </>
              ) : (
                <>
                  <View
                    style={
                      styles.cameraCircle
                    }
                  >
                    <Text
                      style={
                        styles.cameraIcon
                      }
                    >
                      📷
                    </Text>
                  </View>

                  <Text
                    style={
                      styles.photoTitle
                    }
                  >
                    Take a photo
                  </Text>

                  <Text
                    style={
                      styles.photoSubtitle
                    }
                  >
                    Clear e-waste photo only
                  </Text>

                  <Text
                    style={
                      styles.photoHint
                    }
                  >
                    AI will verify the image
                    before you can continue
                  </Text>
                </>
              )}
            </Pressable>

            {/* AI STATUS */}
            {photoUri && (
              <View
                style={[
                  styles.aiStatusBox,

                  validatingPhoto &&
                    styles.aiStatusChecking,

                  photoValidation?.decision ===
                    'ACCEPT' &&
                    styles.aiStatusAccepted,

                  photoValidation?.decision ===
                    'REJECT' &&
                    styles.aiStatusRejected,
                ]}
              >
                <Text
                  style={
                    styles.aiStatusIcon
                  }
                >
                  {validatingPhoto
                    ? '🤖'
                    : photoValidation?.decision ===
                        'ACCEPT'
                      ? '✓'
                      : photoValidation?.decision ===
                          'REJECT'
                        ? '✕'
                        : 'AI'}
                </Text>

                <View
                  style={
                    styles.aiStatusContent
                  }
                >
                  <Text
                    style={
                      styles.aiStatusTitle
                    }
                  >
                    {validatingPhoto
                      ? 'AI is checking your photo'
                      : photoValidation?.decision ===
                          'ACCEPT'
                        ? 'Photo verified successfully'
                        : photoValidation?.decision ===
                            'REJECT'
                          ? 'Photo rejected'
                          : 'Photo verification required'}
                  </Text>

                  <Text
                    style={
                      styles.aiStatusText
                    }
                  >
                    {validatingPhoto
                      ? 'Checking e-waste and material category...'
                      : photoValidation?.reason ||
                        'The photo must match the selected e-waste material.'}
                  </Text>

                  {photoValidation &&
                    !validatingPhoto && (
                      <Text
                        style={
                          styles.aiConfidence
                        }
                      >
                        Confidence:{' '}
                        {Math.round(
                          photoValidation.confidence *
                            100,
                        )}
                        %
                      </Text>
                    )}
                </View>
              </View>
            )}

            {/* PHOTO REQUIRED */}
            {!photoUri && (
              <View
                style={
                  styles.photoRequiredBox
                }
              >
                <Text
                  style={
                    styles.photoRequiredIcon
                  }
                >
                  !
                </Text>

                <View
                  style={
                    styles.photoRequiredContent
                  }
                >
                  <Text
                    style={
                      styles.photoRequiredTitle
                    }
                  >
                    Photo is mandatory
                  </Text>

                  <Text
                    style={
                      styles.photoRequiredText
                    }
                  >
                    You cannot continue without
                    a photo. AI will check whether
                    the image contains e-waste and
                    whether it matches your selected
                    material.
                  </Text>
                </View>
              </View>
            )}

            {/* MATERIAL */}
            <View
              style={
                styles.sectionHeadingRow
              }
            >
              <View style={styles.stepNumber}>
                <Text
                  style={
                    styles.stepNumberText
                  }
                >
                  2
                </Text>
              </View>

              <View>
                <Text
                  style={
                    styles.sectionTitle
                  }
                >
                  What did you collect? *
                </Text>

                <Text
                  style={
                    styles.requiredText
                  }
                >
                  Select the closest material
                </Text>
              </View>
            </View>

            <View
              style={
                styles.materialGrid
              }
            >
              {MATERIALS.map((material) => {
                const selected =
                  category === material.id;

                return (
                  <Pressable
                    key={material.id}
                    onPress={() =>
                      handleCategorySelect(
                        material.id,
                      )
                    }
                    style={[
                      styles.materialCard,
                      selected &&
                        styles.materialCardSelected,
                    ]}
                  >
                    {selected && (
                      <View
                        style={
                          styles.selectedCheck
                        }
                      >
                        <Text
                          style={
                            styles.selectedCheckText
                          }
                        >
                          ✓
                        </Text>
                      </View>
                    )}

                    <Text
                      style={
                        styles.materialIcon
                      }
                    >
                      {material.icon}
                    </Text>

                    <Text
                      style={[
                        styles.materialLabel,
                        selected &&
                          styles.materialLabelSelected,
                      ]}
                    >
                      {material.label}
                    </Text>
                  </Pressable>
                );
              })}
            </View>

            {/* WEIGHT */}
            <Field
              label="Approximate weight (kg)"
              placeholder="Example: 5"
              value={weight}
              onChangeText={(value) =>
                setWeight(
                  value.replace(
                    /[^0-9.]/g,
                    '',
                  ),
                )
              }
            />

            {/* NOTES */}
            <Field
              label="Notes (optional)"
              placeholder="Visible damage, model, brand or useful details"
              value={notes}
              onChangeText={setNotes}
              multiline
            />

            {/* CONTINUE */}
            <Button
              label={
                validatingPhoto
                  ? 'AI checking photo...'
                  : 'Continue to value →'
              }
              onPress={
                continueToStepTwo
              }
            />

            {!photoUri && (
              <Text
                style={
                  styles.blockedHint
                }
              >
                Add a photo to unlock the
                next step
              </Text>
            )}

            {photoUri &&
              photoValidation?.decision !==
                'ACCEPT' &&
              !validatingPhoto && (
                <Text
                  style={
                    styles.blockedHint
                  }
                >
                  AI verification must pass
                  before continuing
                </Text>
              )}
          </>
        ) : (
          /* STEP 2 */
          <>
            {/* REVIEW HEADING */}
            <View
              style={
                styles.sectionHeadingRow
              }
            >
              <View style={styles.stepNumber}>
                <Text
                  style={
                    styles.stepNumberText
                  }
                >
                  3
                </Text>
              </View>

              <View>
                <Text
                  style={
                    styles.sectionTitle
                  }
                >
                  Review your collection
                </Text>

                <Text
                  style={
                    styles.requiredText
                  }
                >
                  AI verified • Check details
                  before saving
                </Text>
              </View>
            </View>

            {/* PHOTO PREVIEW */}
            {photoUri && (
              <View
                style={
                  styles.reviewPhotoBox
                }
              >
                <Image
                  source={{
                    uri: photoUri,
                  }}
                  style={
                    styles.reviewPhoto
                  }
                />

                <View
                  style={
                    styles.reviewPhotoBadge
                  }
                >
                  <Text
                    style={
                      styles.reviewPhotoBadgeText
                    }
                  >
                    ✓ AI VERIFIED
                  </Text>
                </View>
              </View>
            )}

            {/* REVIEW */}
            <View
              style={
                styles.reviewCard
              }
            >
              <View
                style={
                  styles.reviewRow
                }
              >
                <Text
                  style={
                    styles.reviewLabel
                  }
                >
                  Material
                </Text>

                <Text
                  style={
                    styles.reviewValue
                  }
                >
                  {selectedMaterial?.icon}{' '}
                  {selectedMaterial?.label}
                </Text>
              </View>

              <View
                style={
                  styles.reviewRow
                }
              >
                <Text
                  style={
                    styles.reviewLabel
                  }
                >
                  Weight
                </Text>

                <Text
                  style={
                    styles.reviewValue
                  }
                >
                  {weight} kg
                </Text>
              </View>

              <View
                style={
                  styles.reviewRow
                }
              >
                <Text
                  style={
                    styles.reviewLabel
                  }
                >
                  AI verification
                </Text>

                <Text
                  style={[
                    styles.reviewValue,
                    styles.reviewValueSuccess,
                  ]}
                >
                  Passed ✓
                </Text>
              </View>

              <View
                style={
                  styles.reviewRow
                }
              >
                <Text
                  style={
                    styles.reviewLabel
                  }
                >
                  AI confidence
                </Text>

                <Text
                  style={
                    styles.reviewValue
                  }
                >
                  {photoValidation
                    ? `${Math.round(
                        photoValidation.confidence *
                          100,
                      )}%`
                    : '--'}
                </Text>
              </View>

              {notes.trim().length > 0 && (
                <View
                  style={
                    styles.reviewNotes
                  }
                >
                  <Text
                    style={
                      styles.reviewLabel
                    }
                  >
                    Notes
                  </Text>

                  <Text
                    style={
                      styles.reviewNotesText
                    }
                  >
                    {notes}
                  </Text>
                </View>
              )}
            </View>

            {/* AI VALIDATION */}
            <View
              style={
                styles.aiVerifiedBox
              }
            >
              <View
                style={
                  styles.aiVerifiedIcon
                }
              >
                <Text
                  style={
                    styles.aiVerifiedIconText
                  }
                >
                  ✓
                </Text>
              </View>

              <View
                style={
                  styles.aiContent
                }
              >
                <Text
                  style={
                    styles.aiTitle
                  }
                >
                  Material verification passed
                </Text>

                <Text
                  style={
                    styles.aiText
                  }
                >
                  The AI service detected{' '}
                  <Text
                    style={
                      styles.aiBold
                    }
                  >
                    {selectedMaterial?.label}
                  </Text>{' '}
                  and the result matches your
                  selected category.
                </Text>

                <Text
                  style={
                    styles.aiStatus
                  }
                >
                  AI confidence:{' '}
                  {photoValidation
                    ? `${Math.round(
                        photoValidation.confidence *
                          100,
                      )}%`
                    : '--'}
                </Text>
              </View>
            </View>

            {/* VALUE */}
            <View
              style={
                styles.valuationCard
              }
            >
              <Text
                style={
                  styles.valuationLabel
                }
              >
                PRELIMINARY VALUE RANGE
              </Text>

              {estimatedRange ? (
                <>
                  <Text
                    style={
                      styles.valuationAmount
                    }
                  >
                    ₹
                    {estimatedRange.low.toLocaleString(
                      'en-IN',
                    )}
                    {' – '}
                    ₹
                    {estimatedRange.high.toLocaleString(
                      'en-IN',
                    )}
                  </Text>

                  <Text
                    style={
                      styles.confidenceText
                    }
                  >
                    Preliminary estimate • Final
                    price depends on recycler
                    verification, material condition
                    and current market rates.
                  </Text>
                </>
              ) : (
                <Text
                  style={
                    styles.confidenceText
                  }
                >
                  Add material and weight to see
                  an estimate.
                </Text>
              )}
            </View>

            {/* SAFETY */}
            <View
              style={
                styles.warningBox
              }
            >
              <Text
                style={
                  styles.warningTitle
                }
              >
                ⚠️ Important
              </Text>

              <Text
                style={
                  styles.warningText
                }
              >
                This is an estimated range, not a
                guaranteed selling price. Hidden
                faults cannot be determined from a
                photo alone. Damaged, swollen or
                burnt batteries should be handled
                carefully and may require verification.
              </Text>
            </View>

            {/* EDIT */}
            <Button
              label="← Edit details"
              variant="secondary"
              onPress={() =>
                setStep(1)
              }
            />

            {/* SAVE */}
            <Button
              label={
                saving
                  ? 'Saving lot...'
                  : 'Save verified lot on this phone'
              }
              onPress={saveLot}
            />

            <Text
              style={
                styles.finalNote
              }
            >
              ✓ AI verification passed. The lot will
              first be stored offline and receive its
              server reference when synchronization
              is completed.
            </Text>
          </>
        )}
      </Card>

      <Text style={styles.safeNote}>
        🔒 Your lot is stored locally first. AI
        verification, online sync, recycler offers
        and final valuation are handled separately.
      </Text>
    </Screen>
  );
}

const styles = StyleSheet.create({
  progressRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },

  step: {
    ...typography.label,
    color: colors.brand,
  },

  stepStatus: {
    ...typography.label,
    color: colors.muted,
  },

  sectionHeadingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing.sm,
    marginBottom: spacing.sm,
  },

  stepNumber: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: colors.brandSoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.sm,
  },

  stepNumberText: {
    fontSize: 13,
    fontWeight: '900',
    color: colors.brand,
  },

  sectionTitle: {
    ...typography.heading,
    fontSize: 17,
    marginBottom: 2,
  },

  requiredText: {
    fontSize: 10,
    color: colors.muted,
    fontWeight: '600',
  },

  photoBox: {
    height: 205,
    borderWidth: 2,
    borderStyle: 'dashed',
    borderColor: colors.brand,
    borderRadius: 18,
    backgroundColor: colors.canvas,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    marginBottom: spacing.sm,
  },

  photoBoxFilled: {
    borderStyle: 'solid',
  },

  cameraCircle: {
    width: 62,
    height: 62,
    borderRadius: 31,
    backgroundColor: colors.brandSoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.sm,
  },

  cameraIcon: {
    fontSize: 30,
  },

  photoTitle: {
    ...typography.heading,
    fontSize: 18,
  },

  photoSubtitle: {
    ...typography.body,
    color: colors.brand,
    fontWeight: '700',
    marginTop: spacing.xs,
  },

  photoHint: {
    fontSize: 10,
    color: colors.muted,
    marginTop: 5,
    textAlign: 'center',
    paddingHorizontal: spacing.md,
  },

  photoPreview: {
    width: '100%',
    height: '100%',
  },

  verifiedPhotoBadge: {
    position: 'absolute',
    top: 10,
    left: 10,
    backgroundColor: colors.brand,
    paddingHorizontal: 9,
    paddingVertical: 6,
    borderRadius: 9,
  },

  rejectedPhotoBadge: {
    backgroundColor: '#D64545',
  },

  checkingPhotoBadge: {
    backgroundColor: '#356AE6',
  },

  verifiedPhotoText: {
    color: '#FFFFFF',
    fontSize: 9,
    fontWeight: '900',
    letterSpacing: 0.5,
  },

  photoOverlay: {
    position: 'absolute',
    bottom: 10,
    right: 10,
    backgroundColor: 'rgba(0,0,0,0.68)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 10,
  },

  photoOverlayText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 11,
  },

  aiStatusBox: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: '#EEF5FF',
    borderRadius: 15,
    padding: spacing.md,
    marginBottom: spacing.md,
  },

  aiStatusChecking: {
    backgroundColor: '#EEF5FF',
  },

  aiStatusAccepted: {
    backgroundColor: '#EAF8F1',
  },

  aiStatusRejected: {
    backgroundColor: '#FFF0F0',
  },

  aiStatusIcon: {
    width: 38,
    height: 38,
    borderRadius: 12,
    backgroundColor: '#356AE6',
    color: '#FFFFFF',
    textAlign: 'center',
    textAlignVertical: 'center',
    fontSize: 17,
    fontWeight: '900',
    overflow: 'hidden',
  },

  aiStatusContent: {
    flex: 1,
    marginLeft: spacing.sm,
  },

  aiStatusTitle: {
    fontSize: 13,
    fontWeight: '800',
    color: '#1C428A',
  },

  aiStatusText: {
    fontSize: 10,
    lineHeight: 16,
    color: '#526A91',
    marginTop: 3,
  },

  aiConfidence: {
    fontSize: 10,
    fontWeight: '800',
    color: '#356AE6',
    marginTop: 6,
  },

  photoRequiredBox: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: '#FFF7E5',
    borderRadius: 14,
    padding: spacing.sm,
    marginBottom: spacing.md,
  },

  photoRequiredIcon: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#E29A00',
    color: '#FFFFFF',
    textAlign: 'center',
    lineHeight: 24,
    fontWeight: '900',
    marginRight: spacing.sm,
  },

  photoRequiredContent: {
    flex: 1,
  },

  photoRequiredTitle: {
    fontSize: 12,
    fontWeight: '800',
    color: '#8A5A00',
  },

  photoRequiredText: {
    fontSize: 10,
    lineHeight: 16,
    color: '#8A5A00',
    marginTop: 2,
  },

  materialGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: spacing.md,
  },

  materialCard: {
    width: '48%',
    minHeight: 90,
    borderWidth: 1,
    borderColor: '#D7E2DF',
    borderRadius: 15,
    padding: spacing.sm,
    marginBottom: spacing.sm,
    justifyContent: 'center',
    position: 'relative',
  },

  materialCardSelected: {
    borderWidth: 2,
    borderColor: colors.brand,
    backgroundColor: '#E8F6F1',
  },

  selectedCheck: {
    position: 'absolute',
    top: 7,
    right: 7,
    width: 19,
    height: 19,
    borderRadius: 10,
    backgroundColor: colors.brand,
    alignItems: 'center',
    justifyContent: 'center',
  },

  selectedCheckText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '900',
  },

  materialIcon: {
    fontSize: 27,
    marginBottom: 4,
  },

  materialLabel: {
    ...typography.body,
    fontWeight: '700',
  },

  materialLabelSelected: {
    color: colors.brand,
  },

  reviewPhotoBox: {
    height: 165,
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: spacing.md,
    position: 'relative',
  },

  reviewPhoto: {
    width: '100%',
    height: '100%',
  },

  reviewPhotoBadge: {
    position: 'absolute',
    top: 10,
    left: 10,
    backgroundColor: colors.brand,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 9,
  },

  reviewPhotoBadgeText: {
    color: '#FFFFFF',
    fontSize: 9,
    fontWeight: '900',
  },

  reviewCard: {
    backgroundColor: colors.canvas,
    borderRadius: 14,
    padding: spacing.md,
    marginBottom: spacing.md,
  },

  reviewRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: spacing.xs,
  },

  reviewLabel: {
    ...typography.body,
    color: colors.muted,
  },

  reviewValue: {
    ...typography.body,
    fontWeight: '700',
    maxWidth: '58%',
    textAlign: 'right',
  },

  reviewValueSuccess: {
    color: colors.brand,
  },

  reviewNotes: {
    borderTopWidth: 1,
    borderColor: '#D7E2DF',
    marginTop: spacing.xs,
    paddingTop: spacing.sm,
  },

  reviewNotesText: {
    ...typography.body,
    marginTop: 4,
    lineHeight: 20,
  },

  aiVerifiedBox: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: '#EAF8F1',
    borderRadius: 15,
    padding: spacing.md,
    marginBottom: spacing.md,
  },

  aiVerifiedIcon: {
    width: 38,
    height: 38,
    borderRadius: 12,
    backgroundColor: colors.brand,
    alignItems: 'center',
    justifyContent: 'center',
  },

  aiVerifiedIconText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '900',
  },

  aiContent: {
    flex: 1,
    marginLeft: spacing.sm,
  },

  aiTitle: {
    fontSize: 13,
    fontWeight: '800',
    color: '#146B4D',
  },

  aiText: {
    fontSize: 10,
    lineHeight: 16,
    color: '#3D6C59',
    marginTop: 3,
  },

  aiBold: {
    fontWeight: '900',
  },

  aiStatus: {
    fontSize: 9,
    fontWeight: '800',
    color: colors.brand,
    marginTop: 6,
  },

  valuationCard: {
    borderWidth: 1,
    borderColor: colors.brand,
    borderRadius: 16,
    padding: spacing.md,
    marginBottom: spacing.md,
    backgroundColor: '#F2FBF8',
  },

  valuationLabel: {
    ...typography.label,
    color: colors.brand,
  },

  valuationAmount: {
    fontSize: 30,
    fontWeight: '800',
    color: colors.brand,
    marginTop: spacing.xs,
  },

  confidenceText: {
    ...typography.body,
    color: colors.muted,
    marginTop: spacing.xs,
    lineHeight: 21,
  },

  warningBox: {
    backgroundColor: '#FFF8E8',
    borderRadius: 14,
    padding: spacing.md,
    marginBottom: spacing.md,
  },

  warningTitle: {
    fontWeight: '800',
    marginBottom: 4,
  },

  warningText: {
    ...typography.body,
    color: colors.muted,
    lineHeight: 21,
  },

  blockedHint: {
    textAlign: 'center',
    color: colors.muted,
    fontSize: 10,
    fontWeight: '600',
    marginTop: spacing.xs,
  },

  finalNote: {
    textAlign: 'center',
    color: colors.muted,
    fontSize: 10,
    lineHeight: 16,
    marginTop: spacing.sm,
  },

  successIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: colors.brand,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.md,
  },

  successIconText: {
    color: '#FFFFFF',
    fontSize: 34,
    fontWeight: '800',
  },

  savedTitle: {
    ...typography.heading,
    marginTop: spacing.md,
  },

  savedText: {
    ...typography.body,
    color: colors.muted,
    marginTop: spacing.xs,
    marginBottom: spacing.md,
    lineHeight: 21,
  },

  summaryBox: {
    backgroundColor: colors.canvas,
    borderRadius: 14,
    padding: spacing.md,
    marginBottom: spacing.md,
  },

  summaryLabel: {
    ...typography.label,
    color: colors.muted,
    marginTop: spacing.xs,
  },

  summaryValue: {
    ...typography.body,
    fontWeight: '700',
    marginBottom: spacing.xs,
  },

  safeNote: {
    ...typography.body,
    color: colors.muted,
    textAlign: 'center',
    paddingHorizontal: spacing.md,
    marginTop: spacing.sm,
    lineHeight: 21,
  },
});