import {
    Pressable,
    ScrollView,
    StyleSheet,
    Text,
    View,
} from 'react-native';

import type { AppRoute } from '../navigation/types';
import { colors, spacing, typography } from '../theme';

type Props = {
    onNavigate: (route: AppRoute) => void;
};

export function ManufacturerDashboardScreen({
    onNavigate,
}: Props) {
    return (
        <View style={styles.container}>
            <ScrollView
                showsVerticalScrollIndicator={false}
                contentContainerStyle={styles.content}
            >
                {/* Header */}
                <View style={styles.header}>
                    <View style={styles.headerText}>
                        <Text style={styles.greeting}>
                            Welcome back 👋
                        </Text>

                        <Text style={styles.title}>
                            Manufacturer Dashboard
                        </Text>

                        <Text style={styles.subtitle}>
                            Manage your e-waste recovery and recycling
                            partnerships.
                        </Text>
                    </View>

                    <Pressable style={styles.notification}>
                        <Text style={styles.notificationIcon}>
                            🔔
                        </Text>

                        <View style={styles.notificationDot} />
                    </Pressable>
                </View>

                {/* Business Status */}
                <View style={styles.statusCard}>
                    <View style={styles.statusIcon}>
                        <Text style={styles.statusIconText}>
                            ✓
                        </Text>
                    </View>

                    <View style={styles.statusContent}>
                        <Text style={styles.statusTitle}>
                            Manufacturer account
                        </Text>

                        <Text style={styles.statusText}>
                            Your business verification status will
                            appear here.
                        </Text>
                    </View>

                    <Text style={styles.arrow}>›</Text>
                </View>

                {/* Overview */}
                <Text style={styles.sectionTitle}>
                    Recovery Overview
                </Text>

                <View style={styles.summaryGrid}>
                    <SummaryCard
                        icon="📦"
                        title="E-Waste"
                        value="—"
                        subtitle="Collected"
                    />

                    <SummaryCard
                        icon="♻️"
                        title="Recycled"
                        value="—"
                        subtitle="Processed"
                    />

                    <SummaryCard
                        icon="🤝"
                        title="Partners"
                        value="—"
                        subtitle="Active"
                    />

                    <SummaryCard
                        icon="📊"
                        title="Reports"
                        value="—"
                        subtitle="Available"
                    />
                </View>

                {/* Main Actions */}
                <Text style={styles.sectionTitle}>
                    Quick Actions
                </Text>

                <View style={styles.actionGrid}>
                    <ActionCard
                        icon="♻️"
                        title="Recovery Program"
                        subtitle="Manage e-waste recovery"
                        onPress={() => { }}
                    />

                    <ActionCard
                        icon="🤝"
                        title="Find Recycler"
                        subtitle="Connect with recyclers"
                        onPress={() =>
                            onNavigate('myLots')
                        }
                    />

                    <ActionCard
                        icon="📋"
                        title="Compliance"
                        subtitle="Manage recycling records"
                        onPress={() => { }}
                    />

                    <ActionCard
                        icon="📈"
                        title="Reports"
                        subtitle="View recovery reports"
                        onPress={() => { }}
                    />
                </View>

                {/* Material Categories */}
                <View style={styles.sectionHeader}>
                    <Text style={styles.sectionTitle}>
                        Material Streams
                    </Text>

                    <Pressable onPress={() => { }}>
                        <Text style={styles.viewAll}>
                            View all
                        </Text>
                    </Pressable>
                </View>

                <ScrollView
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    contentContainerStyle={styles.categoryScroll}
                >
                    <CategoryCard
                        icon="🖥️"
                        title="Displays"
                    />

                    <CategoryCard
                        icon="🔋"
                        title="Batteries"
                    />

                    <CategoryCard
                        icon="🔧"
                        title="PCB"
                    />

                    <CategoryCard
                        icon="🔌"
                        title="Cables"
                    />

                    <CategoryCard
                        icon="⚙️"
                        title="Motors"
                    />

                    <CategoryCard
                        icon="♻️"
                        title="Plastics"
                    />
                </ScrollView>

                {/* Recovery Partners */}
                <Text style={styles.sectionTitle}>
                    Recovery Partners
                </Text>

                <View style={styles.partnerCard}>
                    <View style={styles.partnerIcon}>
                        <Text style={styles.partnerIconText}>
                            🤝
                        </Text>
                    </View>

                    <View style={styles.partnerContent}>
                        <Text style={styles.partnerTitle}>
                            Authorized recycler network
                        </Text>

                        <Text style={styles.partnerText}>
                            Connect with authorized recycling facilities
                            based on material and location.
                        </Text>
                    </View>

                    <Text style={styles.arrow}>
                        ›
                    </Text>
                </View>

                {/* Compliance */}
                <Text style={styles.sectionTitle}>
                    Compliance & Traceability
                </Text>

                <View style={styles.complianceCard}>
                    <ComplianceRow
                        icon="📸"
                        title="Digital handover"
                        text="Photo and transaction evidence"
                    />

                    <ComplianceRow
                        icon="📍"
                        title="Location tracking"
                        text="Collection and handover location"
                    />

                    <ComplianceRow
                        icon="⚖️"
                        title="Weight records"
                        text="Verified material quantities"
                    />

                    <ComplianceRow
                        icon="🔐"
                        title="Traceability"
                        text="Unique reference for every lot"
                    />
                </View>

                {/* Activity */}
                <View style={styles.sectionHeader}>
                    <Text style={styles.sectionTitle}>
                        Recent Activity
                    </Text>

                    <Pressable onPress={() => { }}>
                        <Text style={styles.viewAll}>
                            View all
                        </Text>
                    </Pressable>
                </View>

                <View style={styles.emptyCard}>
                    <View style={styles.emptyIcon}>
                        <Text style={styles.emptyIconText}>
                            📊
                        </Text>
                    </View>

                    <Text style={styles.emptyTitle}>
                        No recovery activity yet
                    </Text>

                    <Text style={styles.emptyText}>
                        Your collection, recycling and handover
                        activities will appear here.
                    </Text>
                </View>

                {/* Safety */}
                <Pressable
                    style={styles.safetyCard}
                    onPress={() =>
                        onNavigate('safety')
                    }
                >
                    <View style={styles.safetyIcon}>
                        <Text style={styles.safetyIconText}>
                            🛡️
                        </Text>
                    </View>

                    <View style={styles.safetyContent}>
                        <Text style={styles.safetyTitle}>
                            E-Waste Safety
                        </Text>

                        <Text style={styles.safetyText}>
                            Follow safe handling, storage and
                            transportation practices.
                        </Text>
                    </View>

                    <Text style={styles.arrow}>
                        ›
                    </Text>
                </Pressable>
            </ScrollView>

            {/* Bottom Navigation */}
            <View style={styles.bottomNav}>
                <NavItem
                    icon="⌂"
                    label="Home"
                    active
                    onPress={() =>
                        onNavigate('manufacturerDashboard')
                    }
                />

                <NavItem
                    icon="♻️"
                    label="Recovery"
                    onPress={() =>
                        onNavigate('myLots')
                    }
                />

                <NavItem
                    icon="📊"
                    label="Reports"
                    onPress={() =>
                        onNavigate('earnings')
                    }
                />

                <NavItem
                    icon="♙"
                    label="Profile"
                    onPress={() =>
                        onNavigate('profile')
                    }
                />
            </View>
        </View>
    );
}

/* Summary Card */

function SummaryCard({
    icon,
    title,
    value,
    subtitle,
}: {
    icon: string;
    title: string;
    value: string;
    subtitle: string;
}) {
    return (
        <View style={styles.summaryCard}>
            <View style={styles.summaryIcon}>
                <Text style={styles.summaryIconText}>
                    {icon}
                </Text>
            </View>

            <Text style={styles.summaryTitle}>
                {title}
            </Text>

            <Text style={styles.summaryValue}>
                {value}
            </Text>

            <Text style={styles.summarySubtitle}>
                {subtitle}
            </Text>
        </View>
    );
}

/* Action Card */

function ActionCard({
    icon,
    title,
    subtitle,
    onPress,
}: {
    icon: string;
    title: string;
    subtitle: string;
    onPress: () => void;
}) {
    return (
        <Pressable
            onPress={onPress}
            style={({ pressed }) => [
                styles.actionCard,
                pressed && styles.pressed,
            ]}
        >
            <View style={styles.actionIcon}>
                <Text style={styles.actionIconText}>
                    {icon}
                </Text>
            </View>

            <Text style={styles.actionTitle}>
                {title}
            </Text>

            <Text style={styles.actionSubtitle}>
                {subtitle}
            </Text>

            <Text style={styles.actionArrow}>
                →
            </Text>
        </Pressable>
    );
}

/* Category */

function CategoryCard({
    icon,
    title,
}: {
    icon: string;
    title: string;
}) {
    return (
        <Pressable style={styles.categoryCard}>
            <View style={styles.categoryIcon}>
                <Text style={styles.categoryIconText}>
                    {icon}
                </Text>
            </View>

            <Text style={styles.categoryTitle}>
                {title}
            </Text>
        </Pressable>
    );
}

/* Compliance */

function ComplianceRow({
    icon,
    title,
    text,
}: {
    icon: string;
    title: string;
    text: string;
}) {
    return (
        <View style={styles.complianceRow}>
            <View style={styles.complianceIcon}>
                <Text style={styles.complianceIconText}>
                    {icon}
                </Text>
            </View>

            <View style={styles.complianceContent}>
                <Text style={styles.complianceTitle}>
                    {title}
                </Text>

                <Text style={styles.complianceText}>
                    {text}
                </Text>
            </View>

            <Text style={styles.check}>
                ✓
            </Text>
        </View>
    );
}

/* Bottom Navigation */

function NavItem({
    icon,
    label,
    active = false,
    onPress,
}: {
    icon: string;
    label: string;
    active?: boolean;
    onPress: () => void;
}) {
    return (
        <Pressable
            onPress={onPress}
            style={styles.navItem}
        >
            <View
                style={[
                    styles.navIconContainer,
                    active && styles.navIconActive,
                ]}
            >
                <Text
                    style={[
                        styles.navIcon,
                        active &&
                        styles.navIconActiveText,
                    ]}
                >
                    {icon}
                </Text>
            </View>

            <Text
                style={[
                    styles.navLabel,
                    active &&
                    styles.navLabelActive,
                ]}
            >
                {label}
            </Text>
        </Pressable>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.canvas,
    },

    content: {
        paddingHorizontal: spacing.md,
        paddingTop: spacing.lg,
        paddingBottom: 105,
    },

    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginBottom: spacing.lg,
    },

    headerText: {
        flex: 1,
    },

    greeting: {
        fontSize: 14,
        color: colors.muted,
        marginBottom: 4,
    },

    title: {
        ...typography.title,
        fontSize: 25,
    },

    subtitle: {
        fontSize: 14,
        lineHeight: 20,
        color: colors.muted,
        marginTop: 5,
        maxWidth: 295,
    },

    notification: {
        width: 48,
        height: 48,
        borderRadius: 16,
        backgroundColor: colors.surface,
        borderWidth: 1,
        borderColor: colors.border,
        alignItems: 'center',
        justifyContent: 'center',
        marginLeft: 10,
    },

    notificationIcon: {
        fontSize: 21,
    },

    notificationDot: {
        position: 'absolute',
        width: 8,
        height: 8,
        borderRadius: 4,
        backgroundColor: '#D33131',
        right: 9,
        top: 9,
    },

    statusCard: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: spacing.md,
        borderRadius: 20,
        backgroundColor: colors.brandSoft,
        borderWidth: 1,
        borderColor: colors.border,
        marginBottom: spacing.lg,
    },

    statusIcon: {
        width: 44,
        height: 44,
        borderRadius: 22,
        backgroundColor: colors.brand,
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: spacing.sm,
    },

    statusIconText: {
        color: '#FFFFFF',
        fontSize: 22,
        fontWeight: '900',
    },

    statusContent: {
        flex: 1,
    },

    statusTitle: {
        fontSize: 15,
        fontWeight: '800',
        color: colors.ink,
    },

    statusText: {
        fontSize: 12,
        lineHeight: 17,
        color: colors.muted,
        marginTop: 2,
    },

    arrow: {
        fontSize: 28,
        color: colors.brand,
        marginLeft: 8,
    },

    sectionTitle: {
        fontSize: 19,
        fontWeight: '800',
        color: colors.ink,
        marginBottom: spacing.sm,
    },

    summaryGrid: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: spacing.sm,
        marginBottom: spacing.lg,
    },

    summaryCard: {
        width: '48%',
        backgroundColor: colors.surface,
        borderRadius: 19,
        padding: spacing.md,
        borderWidth: 1,
        borderColor: colors.border,
    },

    summaryIcon: {
        width: 38,
        height: 38,
        borderRadius: 12,
        backgroundColor: colors.brandSoft,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: spacing.sm,
    },

    summaryIconText: {
        fontSize: 19,
    },

    summaryTitle: {
        fontSize: 13,
        fontWeight: '700',
        color: colors.muted,
    },

    summaryValue: {
        fontSize: 25,
        fontWeight: '900',
        color: colors.ink,
        marginTop: 4,
    },

    summarySubtitle: {
        fontSize: 11,
        color: colors.muted,
        marginTop: 2,
    },

    actionGrid: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: spacing.sm,
        marginBottom: spacing.lg,
    },

    actionCard: {
        width: '48%',
        minHeight: 145,
        padding: spacing.md,
        borderRadius: 20,
        backgroundColor: colors.surface,
        borderWidth: 1,
        borderColor: colors.border,
        position: 'relative',
    },

    pressed: {
        opacity: 0.72,
    },

    actionIcon: {
        width: 46,
        height: 46,
        borderRadius: 15,
        backgroundColor: colors.brandSoft,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: spacing.sm,
    },

    actionIconText: {
        fontSize: 22,
    },

    actionTitle: {
        fontSize: 15,
        lineHeight: 20,
        fontWeight: '800',
        color: colors.ink,
    },

    actionSubtitle: {
        fontSize: 12,
        lineHeight: 17,
        color: colors.muted,
        marginTop: 4,
        paddingRight: 8,
    },

    actionArrow: {
        position: 'absolute',
        right: 14,
        bottom: 13,
        fontSize: 18,
        color: colors.brand,
        fontWeight: '800',
    },

    sectionHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },

    viewAll: {
        fontSize: 13,
        fontWeight: '800',
        color: colors.brand,
        marginBottom: spacing.sm,
    },

    categoryScroll: {
        gap: spacing.sm,
        paddingBottom: spacing.lg,
    },

    categoryCard: {
        width: 105,
        height: 112,
        borderRadius: 18,
        backgroundColor: colors.surface,
        borderWidth: 1,
        borderColor: colors.border,
        alignItems: 'center',
        justifyContent: 'center',
    },

    categoryIcon: {
        width: 48,
        height: 48,
        borderRadius: 16,
        backgroundColor: colors.brandSoft,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 8,
    },

    categoryIconText: {
        fontSize: 23,
    },

    categoryTitle: {
        fontSize: 12,
        fontWeight: '700',
        color: colors.ink,
        textAlign: 'center',
    },

    partnerCard: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: colors.brandSoft,
        borderRadius: 20,
        padding: spacing.md,
        borderWidth: 1,
        borderColor: colors.border,
        marginBottom: spacing.lg,
    },

    partnerIcon: {
        width: 48,
        height: 48,
        borderRadius: 16,
        backgroundColor: colors.surface,
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: spacing.sm,
    },

    partnerIconText: {
        fontSize: 24,
    },

    partnerContent: {
        flex: 1,
    },

    partnerTitle: {
        fontSize: 15,
        fontWeight: '800',
        color: colors.ink,
    },

    partnerText: {
        fontSize: 12,
        lineHeight: 17,
        color: colors.muted,
        marginTop: 3,
    },

    complianceCard: {
        backgroundColor: colors.surface,
        borderRadius: 21,
        borderWidth: 1,
        borderColor: colors.border,
        paddingHorizontal: spacing.md,
        marginBottom: spacing.lg,
    },

    complianceRow: {
        minHeight: 68,
        flexDirection: 'row',
        alignItems: 'center',
        borderBottomWidth: 1,
        borderBottomColor: colors.border,
    },

    complianceIcon: {
        width: 40,
        height: 40,
        borderRadius: 13,
        backgroundColor: colors.brandSoft,
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: spacing.sm,
    },

    complianceIconText: {
        fontSize: 19,
    },

    complianceContent: {
        flex: 1,
    },

    complianceTitle: {
        fontSize: 14,
        fontWeight: '800',
        color: colors.ink,
    },

    complianceText: {
        fontSize: 11,
        color: colors.muted,
        marginTop: 2,
    },

    check: {
        fontSize: 17,
        color: colors.brand,
        fontWeight: '900',
        marginLeft: 8,
    },

    emptyCard: {
        backgroundColor: colors.surface,
        borderRadius: 22,
        borderWidth: 1,
        borderColor: colors.border,
        padding: spacing.xl,
        alignItems: 'center',
        marginBottom: spacing.lg,
    },

    emptyIcon: {
        width: 65,
        height: 65,
        borderRadius: 33,
        backgroundColor: colors.brandSoft,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: spacing.sm,
    },

    emptyIconText: {
        fontSize: 29,
    },

    emptyTitle: {
        fontSize: 16,
        fontWeight: '800',
        color: colors.ink,
        textAlign: 'center',
    },

    emptyText: {
        fontSize: 13,
        lineHeight: 19,
        color: colors.muted,
        textAlign: 'center',
        marginTop: 6,
    },

    safetyCard: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: colors.warningSoft,
        borderRadius: 20,
        padding: spacing.md,
        borderWidth: 1,
        borderColor: '#F0D9A7',
    },

    safetyIcon: {
        width: 45,
        height: 45,
        borderRadius: 15,
        backgroundColor: colors.surface,
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: spacing.sm,
    },

    safetyIconText: {
        fontSize: 23,
    },

    safetyContent: {
        flex: 1,
    },

    safetyTitle: {
        fontSize: 15,
        fontWeight: '800',
        color: colors.ink,
    },

    safetyText: {
        fontSize: 12,
        lineHeight: 17,
        color: colors.muted,
        marginTop: 2,
    },

    bottomNav: {
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: 0,
        height: 76,
        backgroundColor: colors.surface,
        borderTopWidth: 1,
        borderTopColor: colors.border,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-around',
        paddingBottom: 6,
    },

    navItem: {
        width: 75,
        alignItems: 'center',
        justifyContent: 'center',
    },

    navIconContainer: {
        width: 42,
        height: 32,
        borderRadius: 12,
        alignItems: 'center',
        justifyContent: 'center',
    },

    navIconActive: {
        backgroundColor: colors.brandSoft,
    },

    navIcon: {
        fontSize: 21,
        color: colors.muted,
    },

    navIconActiveText: {
        color: colors.brand,
        fontWeight: '900',
    },

    navLabel: {
        fontSize: 10,
        fontWeight: '700',
        color: colors.muted,
        marginTop: 2,
    },

    navLabelActive: {
        color: colors.brand,
    },
});