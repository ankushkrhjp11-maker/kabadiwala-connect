import { Text, StyleSheet, View } from 'react-native';
import type { AppLanguage, AppRoute } from '../navigation/types';
import { Button, Card } from '../components/UI';
import { colors, spacing, typography } from '../theme';

const languages: Array<{ id: AppLanguage; native: string; english: string }> = [
  { id: 'hi', native: 'हिन्दी', english: 'Hindi' },
  { id: 'mr', native: 'मराठी', english: 'Marathi' },
  { id: 'en', native: 'English', english: 'English' },
];

export function LanguageScreen({ onSelect }: { onSelect: (language: AppLanguage, route: AppRoute) => void }) {
  return <View style={styles.container}><Text style={typography.title}>Choose your language</Text><Text style={styles.subtitle}>अपनी भाषा चुनें · तुमची भाषा निवडा</Text><Text style={styles.hint}>You can change this later in Profile.</Text><View style={styles.list}>{languages.map((language) => <Card key={language.id} onPress={() => onSelect(language.id, 'login')}><View style={styles.row}><View><Text style={styles.native}>{language.native}</Text><Text style={styles.english}>{language.english}</Text></View><Text style={styles.arrow}>›</Text></View></Card>)}</View><Button label="Continue in English" variant="quiet" onPress={() => onSelect('en', 'login')} /></View>;
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.canvas, padding: spacing.lg, paddingTop: 72 },
  subtitle: { ...typography.body, color: colors.muted, marginTop: spacing.xs },
  hint: { ...typography.body, color: colors.muted, marginTop: spacing.xl, marginBottom: spacing.md },
  list: { marginTop: spacing.sm },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  native: { ...typography.heading },
  english: { ...typography.body, color: colors.muted, marginTop: 2 },
  arrow: { color: colors.brand, fontSize: 32, fontWeight: '300' },
});
