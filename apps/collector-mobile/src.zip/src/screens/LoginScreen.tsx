import { useState } from 'react';

import {
  Text,
  StyleSheet,
  View,
} from 'react-native';

import {
  Button,
  Card,
  Field,
} from '../components/UI';

import { Screen } from '../components/Screen';

import type {
  AppLanguage,
  AppRoute,
} from '../navigation/types';

import {
  colors,
  spacing,
  typography,
} from '../theme';

type Props = {
  language: AppLanguage;
  onNavigate: (route: AppRoute) => void;
  onPhoneChange: (phone: string) => void;
};

export function LoginScreen({
  language,
  onNavigate,
  onPhoneChange,
}: Props) {
  const [phone, setPhone] = useState('');
  const [error, setError] = useState('');

  const label =
    language === 'hi'
      ? 'मोबाइल नंबर'
      : language === 'mr'
        ? 'मोबाईल नंबर'
        : 'Mobile number';

  return (
    <Screen
      title="Welcome"
      subtitle="Sign in to manage your collection work."
    >
      <Card accent>
        <Text style={styles.privacy}>
          Your number is used only for your account.
        </Text>

        <Field
          label={label}
          placeholder="10-digit mobile number"
          value={phone}
          onChangeText={(value) => {
            const cleaned = value
              .replace(/\D/g, '')
              .slice(0, 10);

            setPhone(cleaned);
            onPhoneChange(cleaned);
            setError('');
          }}
        />

        {error ? (
          <Text style={styles.error}>
            {error}
          </Text>
        ) : null}

        <Button
          label="Send OTP"
          onPress={() => {
            if (phone.length === 10) {
              onNavigate('otp');
            } else {
              setError(
                'Please enter a valid 10-digit number.',
              );
            }
          }}
        />
      </Card>

      <View style={styles.offline}>
        <Text style={styles.offlineIcon}>
          ⌁
        </Text>

        <Text style={styles.offlineTitle}>
          Works in low network areas
        </Text>

        <Text style={styles.offlineText}>
          Your saved work stays on your phone and
          syncs when you reconnect.
        </Text>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  privacy: {
    ...typography.body,
    color: colors.muted,
    marginBottom: spacing.md,
  },

  error: {
    color: colors.danger,
    fontSize: 13,
    marginTop: -8,
    marginBottom: 4,
  },

  offline: {
    alignItems: 'center',
    marginTop: spacing.xl,
    paddingHorizontal: spacing.lg,
  },

  offlineIcon: {
    color: colors.brand,
    fontSize: 30,
  },

  offlineTitle: {
    ...typography.heading,
    fontSize: 17,
    marginTop: spacing.sm,
  },

  offlineText: {
    ...typography.body,
    textAlign: 'center',
    color: colors.muted,
    marginTop: spacing.xs,
  },
});