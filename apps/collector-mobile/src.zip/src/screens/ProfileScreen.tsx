import { Alert, Text, StyleSheet, View } from 'react-native';

import { Screen } from '../components/Screen';
import { Button, Card } from '../components/UI';
import type { AppLanguage, AppRoute } from '../navigation/types';
import { colors, spacing, typography } from '../theme';

import { clearSession } from '../services/authStorage';

export function ProfileScreen({
  language,
  onNavigate,
}: {
  language: AppLanguage;
  onNavigate: (route: AppRoute) => void;
}) {
  const languageName =
    language === 'hi'
      ? 'हिन्दी'
      : language === 'mr'
        ? 'मराठी'
        : 'English';

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Logout',
          style: 'destructive',
          onPress: async () => {
            try {
              await clearSession();

              // Login screen par bhejo
              onNavigate('login');
            } catch (error) {
              console.error(
                'Logout failed:',
                error,
              );

              Alert.alert(
                'Logout failed',
                'Unable to logout. Please try again.',
              );
            }
          },
        },
      ],
    );
  };

  return (
    <Screen
      title="My profile"
      subtitle="Your account and app settings."
    >
      {/* Profile Card */}
      <Card accent>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>C</Text>
        </View>

        <Text style={styles.name}>
          Collector account
        </Text>

        <Text style={styles.phone}>
          Mobile number will appear after login
        </Text>
      </Card>

      {/* Language */}
      <Card>
        <Text style={typography.label}>
          APP LANGUAGE
        </Text>

        <Text style={styles.setting}>
          {languageName}
        </Text>

        <Button
          label="Change language"
          variant="secondary"
          onPress={() =>
            onNavigate('language')
          }
        />
      </Card>

      {/* Help & Trust */}
      <Card>
        <Text style={typography.label}>
          HELP & TRUST
        </Text>

        <Text style={styles.item}>
          Safety guidance
        </Text>

        <Text style={styles.item}>
          Privacy and support
        </Text>

        <Text style={styles.item}>
          App version 0.1.0
        </Text>
      </Card>

      {/* Logout */}
      <Card>
        <Text style={typography.label}>
          ACCOUNT
        </Text>

        <Text style={styles.logoutDescription}>
          Sign out from this device. Your
          registration and saved role will remain
          محفوظ in your account.
        </Text>

        <View style={styles.logoutButton}>
          <Button
            label="Logout"
            variant="secondary"
            onPress={handleLogout}
          />
        </View>
      </Card>
    </Screen>
  );
}

const styles = StyleSheet.create({
  avatar: {
    width: 58,
    height: 58,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.brandSoft,
  },

  avatarText: {
    fontSize: 25,
    fontWeight: '900',
    color: colors.brand,
  },

  name: {
    ...typography.heading,
    marginTop: spacing.md,
  },

  phone: {
    ...typography.body,
    color: colors.muted,
    marginTop: 2,
  },

  setting: {
    ...typography.body,
    fontWeight: '800',
    marginTop: spacing.xs,
  },

  item: {
    ...typography.body,
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },

  logoutDescription: {
    ...typography.body,
    color: colors.muted,
    marginTop: spacing.xs,
    lineHeight: 21,
  },

  logoutButton: {
    marginTop: spacing.md,
  },
});