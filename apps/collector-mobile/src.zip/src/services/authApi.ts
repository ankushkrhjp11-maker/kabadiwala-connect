import {
  getSession,
  saveSession,
  clearSession as clearStoredSession,
} from './authStorage';

/* =========================================================
   API CONFIG
   ========================================================= */

export const API_BASE_URL =
  process.env.EXPO_PUBLIC_API_URL ??
  'http://10.106.189.160:3001/api';

/* =========================================================
   TYPES
   ========================================================= */

type AuthResponse = {
  accessToken: string;
  refreshToken: string;

  user: {
    id: string;
    phone: string;
    role: string;
  };
};

export type BusinessRoleApi =
  | 'RECYCLER'
  | 'TRADER'
  | 'MANUFACTURER';

export type UpdateMyProfileData = {
  name: string;
  email: string;
  dateOfBirth: string;
  businessRole: BusinessRoleApi;
  profileImageReference?: string;
};

/* =========================================================
   RESPONSE PARSER
   ========================================================= */

async function parseResponse(
  response: Response,
) {
  const text =
    await response.text();

  if (!text) {
    return {};
  }

  try {
    return JSON.parse(text);
  } catch {
    return {
      message: text,
    };
  }
}

/* =========================================================
   LOGIN
   ========================================================= */

export async function loginWithPhone(
  phone: string,
): Promise<AuthResponse> {
  const cleanPhone =
    phone.replace(/\D/g, '');

  const response =
    await fetch(
      `${API_BASE_URL}/auth/login`,
      {
        method: 'POST',

        headers: {
          'Content-Type':
            'application/json',

          Accept:
            'application/json',
        },

        body: JSON.stringify({
          phone: cleanPhone,
        }),
      },
    );

  const data =
    await parseResponse(response);

  if (!response.ok) {
    const message =
      Array.isArray(data?.message)
        ? data.message.join(', ')
        : data?.message;

    throw new Error(
      message ??
        'Login failed',
    );
  }

  if (
    !data?.accessToken ||
    !data?.refreshToken ||
    !data?.user
  ) {
    throw new Error(
      'Invalid authentication response from server',
    );
  }

  return data as AuthResponse;
}

/* =========================================================
   RESTORE SESSION
   ========================================================= */

export async function restoreSession() {
  const session =
    await getSession();

  if (!session) {
    return null;
  }

  try {
    const response =
      await fetch(
        `${API_BASE_URL}/auth/me`,
        {
          method: 'GET',

          headers: {
            Accept:
              'application/json',

            Authorization:
              `Bearer ${session.accessToken}`,
          },
        },
      );

    /*
     * Access token expired or invalid.
     */
    if (!response.ok) {
      return null;
    }

    return session;
  } catch (error) {
    console.error(
      'Session restore failed:',
      error,
    );

    return null;
  }
}

/* =========================================================
   SAVE AUTH SESSION
   ========================================================= */

export async function saveAuthSession(
  response: AuthResponse,

  businessRole:
    | 'Recycler'
    | 'Trader'
    | 'Manufacturer',
) {
  await saveSession({
    accessToken:
      response.accessToken,

    refreshToken:
      response.refreshToken,

    phone:
      response.user.phone,

    businessRole,
  });
}

/* =========================================================
   GET MY PROFILE
   ========================================================= */

export async function getMyProfile() {
  const session =
    await getSession();

  if (!session) {
    throw new Error(
      'Session not found',
    );
  }

  const response =
    await fetch(
      `${API_BASE_URL}/users/me/profile`,
      {
        method: 'GET',

        headers: {
          Accept:
            'application/json',

          Authorization:
            `Bearer ${session.accessToken}`,
        },
      },
    );

  const data =
    await parseResponse(response);

  if (!response.ok) {
    const message =
      Array.isArray(data?.message)
        ? data.message.join(', ')
        : data?.message;

    throw new Error(
      message ??
        'Unable to load profile',
    );
  }

  return data;
}

/* =========================================================
   UPDATE MY PROFILE
   ========================================================= */

export async function updateMyProfile(
  profile: UpdateMyProfileData,
) {
  const session =
    await getSession();

  if (!session) {
    throw new Error(
      'Session not found',
    );
  }

  const response =
    await fetch(
      `${API_BASE_URL}/users/me/profile`,
      {
        method: 'PUT',

        headers: {
          'Content-Type':
            'application/json',

          Accept:
            'application/json',

          Authorization:
            `Bearer ${session.accessToken}`,
        },

        body: JSON.stringify(
          profile,
        ),
      },
    );

  const data =
    await parseResponse(response);

  if (!response.ok) {
    const message =
      Array.isArray(data?.message)
        ? data.message.join(', ')
        : data?.message;

    throw new Error(
      message ??
        'Unable to update profile',
    );
  }

  return data;
}

/* =========================================================
   CLEAR SESSION
   =========================================================
   
   IMPORTANT:
   AppNavigator imports clearSession from authApi.
   So authApi must export it.
   ========================================================= */

export async function clearSession() {
  await clearStoredSession();
}