import {
  useEffect,
  useState,
} from 'react';

import { LanguageScreen } from '../screens/LanguageScreen';
import { LoginScreen } from '../screens/LoginScreen';
import { OtpScreen } from '../screens/OtpScreen';
import { RoleSelectionScreen } from '../screens/RoleSelectionScreen';

import {
  RecyclerDashboardScreen,
} from '../screens/RecyclerDashboardScreen';

import {
  TraderDashboardScreen,
} from '../screens/TraderDashboardScreen';

import {
  ManufacturerDashboardScreen,
} from '../screens/ManufacturerDashboardScreen';

import { RegisterScreen } from '../screens/RegisterScreen';

import {
  CreateLotScreen,
} from '../screens/CreateLotScreen';

import {
  MyLotsScreen,
} from '../screens/MyLotsScreen';

import {
  EarningsScreen,
} from '../screens/EarningsScreen';

import {
  SafetyScreen,
} from '../screens/SafetyScreen';

import {
  ProfileScreen,
} from '../screens/ProfileScreen';

import {
  getMyProfile,
  getSession,
  clearSession,
} from '../services/authApi';

import type {
  AppRoute,
  BusinessRole,
} from './types';

/* =========================================================
   LANGUAGE
   ========================================================= */

type Language =
  | 'EN'
  | 'HI'
  | 'MR';

/* =========================================================
   APP NAVIGATOR
   ========================================================= */

export function AppNavigator() {
  const [
    route,
    setRoute,
  ] = useState<AppRoute>(
    'language',
  );

  const [
    navigationHistory,
    setNavigationHistory,
  ] = useState<AppRoute[]>([]);

  const [
    language,
    setLanguage,
  ] = useState<Language>('EN');

  const [
    businessRole,
    setBusinessRole,
  ] = useState<BusinessRole | null>(
    null,
  );

  const [
    loginPhone,
    setLoginPhone,
  ] = useState('');

  const [
    checkingSession,
    setCheckingSession,
  ] = useState(true);

  /* =======================================================
     RESTORE SESSION
     ======================================================= */

  useEffect(() => {
    let mounted = true;

    async function restore() {
      try {
        const session =
          await getSession();

        if (!mounted) {
          return;
        }

        /*
         * No session.
         */
        if (!session) {
          setCheckingSession(false);
          return;
        }

        setLoginPhone(
          session.phone,
        );

        try {
          /*
           * Always prefer the latest
           * role from backend.
           */
          const profile =
            await getMyProfile();

          if (!mounted) {
            return;
          }

          const apiRole =
            profile?.businessRole;

          /* -----------------------------------------------
             RECYCLER
             ----------------------------------------------- */

          if (
            apiRole === 'RECYCLER'
          ) {
            setBusinessRole(
              'Recycler',
            );

            setRoute(
              'recyclerDashboard',
            );

            return;
          }

          /* -----------------------------------------------
             TRADER
             ----------------------------------------------- */

          if (
            apiRole === 'TRADER'
          ) {
            setBusinessRole(
              'Trader',
            );

            setRoute(
              'traderDashboard',
            );

            return;
          }

          /* -----------------------------------------------
             MANUFACTURER
             ----------------------------------------------- */

          if (
            apiRole === 'MANUFACTURER'
          ) {
            setBusinessRole(
              'Manufacturer',
            );

            setRoute(
              'manufacturerDashboard',
            );

            return;
          }

          /*
           * No business role yet.
           */
          setRoute(
            'roleSelection',
          );
        } catch (error) {
          /*
           * Backend profile unavailable.
           * Use locally saved role as fallback.
           */

          console.warn(
            'Profile restore failed:',
            error,
          );

          const savedRole =
            session.businessRole;

          if (
            savedRole === 'Recycler'
          ) {
            setBusinessRole(
              'Recycler',
            );

            setRoute(
              'recyclerDashboard',
            );
          } else if (
            savedRole === 'Trader'
          ) {
            setBusinessRole(
              'Trader',
            );

            setRoute(
              'traderDashboard',
            );
          } else if (
            savedRole === 'Manufacturer'
          ) {
            setBusinessRole(
              'Manufacturer',
            );

            setRoute(
              'manufacturerDashboard',
            );
          } else {
            setRoute(
              'roleSelection',
            );
          }
        }
      } catch (error) {
        console.error(
          'Session initialization failed:',
          error,
        );

        setRoute('login');
      } finally {
        if (mounted) {
          setCheckingSession(false);
        }
      }
    }

    restore();

    return () => {
      mounted = false;
    };
  }, []);

  /* =======================================================
     NAVIGATION
     ======================================================= */

  const navigateTo = (
    nextRoute: AppRoute,
  ) => {
    /*
     * CREATE LOT IS RECYCLER ONLY.
     *
     * Trader and Manufacturer are
     * explicitly blocked.
     */

    if (
      nextRoute === 'createLot' &&
      businessRole !== 'Recycler'
    ) {
      console.warn(
        'Create Lot is available only for Recycler.',
      );

      return;
    }

    setNavigationHistory(
      (current) => [
        ...current,
        route,
      ],
    );

    setRoute(
      nextRoute,
    );
  };

  /* =======================================================
     REPLACE ROUTE
     ======================================================= */

  const replaceRoute = (
    nextRoute: AppRoute,
  ) => {
    setNavigationHistory([]);

    setRoute(
      nextRoute,
    );
  };

  /* =======================================================
     BACK
     ======================================================= */

  const goBack = () => {
    setNavigationHistory(
      (current) => {
        if (
          current.length === 0
        ) {
          return current;
        }

        const previousRoute =
          current[
            current.length - 1
          ];

        setRoute(
          previousRoute,
        );

        return current.slice(
          0,
          -1,
        );
      },
    );
  };

  /* =======================================================
     LOGOUT
     ======================================================= */

  const logout = async () => {
    try {
      await clearSession();
    } catch (error) {
      console.error(
        'Logout failed:',
        error,
      );
    } finally {
      setBusinessRole(null);

      setLoginPhone('');

      setNavigationHistory([]);

      setRoute('login');
    }
  };

  /* =======================================================
     LOADING
     ======================================================= */

  if (checkingSession) {
    return null;
  }

  /* =======================================================
     LANGUAGE
     ======================================================= */

  if (
    route === 'language'
  ) {
    return (
      <LanguageScreen
        language={language}
        onSelectLanguage={(
          selectedLanguage,
        ) => {
          setLanguage(
            selectedLanguage,
          );

          replaceRoute(
            'login',
          );
        }}
      />
    );
  }

  /* =======================================================
     LOGIN
     ======================================================= */

  if (
    route === 'login'
  ) {
    return (
      <LoginScreen
        onContinue={(phone) => {
          setLoginPhone(
            phone,
          );

          navigateTo(
            'otp',
          );
        }}
        onRegister={() => {
          navigateTo(
            'register',
          );
        }}
      />
    );
  }

  /* =======================================================
     OTP
     ======================================================= */

  if (
    route === 'otp'
  ) {
    return (
      <OtpScreen
        phone={loginPhone}
        onSuccess={(role) => {
          setBusinessRole(
            role,
          );

          if (
            role === 'Recycler'
          ) {
            replaceRoute(
              'recyclerDashboard',
            );
          } else if (
            role === 'Trader'
          ) {
            replaceRoute(
              'traderDashboard',
            );
          } else if (
            role === 'Manufacturer'
          ) {
            replaceRoute(
              'manufacturerDashboard',
            );
          } else {
            replaceRoute(
              'roleSelection',
            );
          }
        }}
        onBack={goBack}
      />
    );
  }

  /* =======================================================
     REGISTER
     ======================================================= */

  if (
    route === 'register'
  ) {
    return (
      <RegisterScreen
        onSuccess={(phone) => {
          setLoginPhone(
            phone,
          );

          replaceRoute(
            'otp',
          );
        }}
        onBack={goBack}
      />
    );
  }

  /* =======================================================
     ROLE SELECTION
     ======================================================= */

  if (
    route === 'roleSelection'
  ) {
    return (
      <RoleSelectionScreen
        onSelectRole={(role) => {
          setBusinessRole(
            role,
          );

          if (
            role === 'Recycler'
          ) {
            replaceRoute(
              'recyclerDashboard',
            );
          } else if (
            role === 'Trader'
          ) {
            replaceRoute(
              'traderDashboard',
            );
          } else if (
            role === 'Manufacturer'
          ) {
            replaceRoute(
              'manufacturerDashboard',
            );
          }
        }}
        onBack={goBack}
      />
    );
  }

  /* =======================================================
     RECYCLER DASHBOARD
     ======================================================= */

  if (
    route === 'recyclerDashboard'
  ) {
    return (
      <RecyclerDashboardScreen
        onNavigate={
          navigateTo
        }
      />
    );
  }

  /* =======================================================
     TRADER DASHBOARD
     ======================================================= */

  if (
    route === 'traderDashboard'
  ) {
    return (
      <TraderDashboardScreen
        onNavigate={
          navigateTo
        }
      />
    );
  }

  /* =======================================================
     MANUFACTURER DASHBOARD
     ======================================================= */

  if (
    route === 'manufacturerDashboard'
  ) {
    return (
      <ManufacturerDashboardScreen
        onNavigate={
          navigateTo
        }
      />
    );
  }

  /* =======================================================
     CREATE LOT
     ======================================================= */

  if (
    route === 'createLot'
  ) {
    /*
     * HARD GUARD:
     *
     * Only Recycler can ever see this screen.
     */

    if (
      businessRole !== 'Recycler'
    ) {
      return null;
    }

    return (
      <CreateLotScreen
        onBack={goBack}
        onComplete={() => {
          replaceRoute(
            'myLots',
          );
        }}
      />
    );
  }

  /* =======================================================
     MY LOTS
     ======================================================= */

  if (
    route === 'myLots'
  ) {
    return (
      <MyLotsScreen
        onBack={goBack}
        onNavigate={
          navigateTo
        }
      />
    );
  }

  /* =======================================================
     EARNINGS
     ======================================================= */

  if (
    route === 'earnings'
  ) {
    return (
      <EarningsScreen
        onBack={goBack}
      />
    );
  }

  /* =======================================================
     SAFETY
     ======================================================= */

  if (
    route === 'safety'
  ) {
    return (
      <SafetyScreen
        onBack={goBack}
      />
    );
  }

  /* =======================================================
     PROFILE
     ======================================================= */

  if (
    route === 'profile'
  ) {
    return (
      <ProfileScreen
        onBack={goBack}
        onLogout={logout}
      />
    );
  }

  /* =======================================================
     FALLBACK
     ======================================================= */

  return null;
}